-- Pastebin Configuration using the official mod key
local API_DEV_KEY = "v1mO2INEooS603Tl4hruLtmhUSaCEHlk"

local args = { ... }
local filename = args[1]

if not filename then
    print("Usage: upload [filename]")
    return
end

if not fs.exists(filename) then
    print("Error: File not found.")
    return
end

-- Read target file
local file = fs.open(filename, "r")
local content = file.readAll()
file.close()

print("Connecting to pastebin.com... ")

-- Correct payload format from the official CC source code
local uploadPayload = "api_option=paste&" ..
                      "api_dev_key=" .. API_DEV_KEY .. "&" ..
                      "api_paste_format=lua&" ..
                      "api_paste_name=" .. textutils.urlEncode(filename) .. "&" ..
                      "api_paste_code=" .. textutils.urlEncode(content)

local response, err = http.post("https://pastebin.com/api/api_post.php", uploadPayload)

if response then
    local resultUrl = response.readAll()
    response.close()
    
    if resultUrl:match("https://pastebin.com") then
        print("Success!")
        print("Link: " .. resultUrl)
    else
        print("Upload failed: " .. resultUrl)
    end
else
    print("Failed.")
    if err then print("Reason: " .. tostring(err)) end
end
