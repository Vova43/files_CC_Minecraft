local radarMon = peripheral.find("create_radar:monitor")

if not radarMon then
    error("xError")
end

local bridge = peripheral.find("redstone_link_bridge")

if not bridge then
    error("xError")
end

local playerWasPresent = false

while true do
    term.clear()
    term.setCursorPos(1, 1)
    
    local tracks = radarMon.getTracks()
    local playersFound = 0
	
	bridge.sendLinkSignal("minecraft:cobblestone", "minecraft:redstone", 0)
    
    if tracks then
        for i = 1, #tracks do
            local target = tracks[i]
            
            if target.category == "PLAYER" then
                playersFound = playersFound + 1
                
                local pos = target.position or {}
                local x = pos.x or 0
                local y = pos.y or 0
                local z = pos.z or 0
                
                local vel = target.velocity or {}
                local vx = vel.x or 0
                local vy = vel.y or 0
                local vz = vel.z or 0
                
                print(string.format("%d. player! id:%s", playersFound, target.id))
                print(string.format(" C: X:%.1f Y:%.1f Z:%.1f", x, y, z))
                
                local speed = math.sqrt(vx^2 + vy^2 + vz^2)
                if speed > 0.1 then
                    print(string.format(" Vspeed: %.2f m/s", speed * 20))
                end
                
            end
        end
    end
    
    -- if playersFound == 0 then
        -- print("null...")
	-- else
		-- bridge.sendLinkSignal("minecraft:cobblestone", "minecraft:redstone", 0)
		-- bridge.sendLinkSignal("minecraft:cobblestone", "minecraft:redstone", 15)
		-- sleep(1.5)
		-- bridge.sendLinkSignal("minecraft:cobblestone", "minecraft:redstone", 0)
    -- end
	
	if playersFound > 0 then
        if not playerWasPresent then
            print("\n[!] NEW PLAYER DETECTED! Activating signal...")
            bridge.sendLinkSignal("minecraft:cobblestone", "minecraft:redstone", 15)
            sleep(1.5)
            bridge.sendLinkSignal("minecraft:cobblestone", "minecraft:redstone", 0)
            print("Signal turned off.")
            playerWasPresent = true
        else
            print("\nPlayer is still on base. Waiting for them to leave...")
        end
    else
        print("null...")
        if playerWasPresent then
            print("Base is clear now.")
            playerWasPresent = false
        end
    end
    
    sleep(0.5)
end
