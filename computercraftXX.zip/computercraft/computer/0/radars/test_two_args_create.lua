local side = "top" -- Укажите вашу сторону блока
local m = peripheral.wrap(side)

if not m then
    print("Block not found!")
    return
end

print("=== TESTING DIRECTION WITH 2 ARGUMENTS ===")

-- Тест 1: Движение с флагом 1
print("\n1. Testing move(5, 1)...")
m.move(5, 1)
os.sleep(3)
print("Is running: " .. tostring(m.isRunning()))

-- Тест 2: Движение с флагом -1 (Проверяем реверс!)
print("\n2. Testing move(5, -1)...")
m.move(5, -1)
os.sleep(3)
print("Is running: " .. tostring(m.isRunning()))

-- Тест 3: Вращение с флагом 1
print("\n3. Testing rotate(45, 1)...")
local ok1, err1 = pcall(m.rotate, 45, 1)
if ok1 then os.sleep(3) else print("Error: " .. tostring(err1)) end

-- Тест 4: Вращение с флагом -1 (Проверяем реверс вращения!)
print("\n4. Testing rotate(45, -1)...")
local ok2, err2 = pcall(m.rotate, 45, -1)
if ok2 then os.sleep(3) else print("Error: " .. tostring(err2)) end

print("\n=== TEST END ===")
