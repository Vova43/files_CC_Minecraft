local side = "back" -- top -- Укажите сторону, где стоит проверяемый блок
local b = peripheral.wrap(side)

if not b then
    print("Error: Block not found on side: " .. side)
    return
end

print("=== STARTING BEARING TEST ===")
print("Initial angle: " .. tostring(b.getAngle()))

-- Массив тестовых углов для проверки (в градусах)
local test_angles = { 90, 180, 270, 0 }

for _, angle in ipairs(test_angles) do
    print(string.format("\nSending command: setAngle(%d)", angle))
    
    -- Вызываем метод установки угла
    b.setAngle(angle)
    
    -- Даем блоку 3 секунды, чтобы он физически докрутился в игре
    os.sleep(3)
    
    -- Проверяем, что вернул блок после поворота
    local current = b.getAngle()
    print("Current angle in game: " .. tostring(current))
end

print("\n=== TEST COMPLETED ===")
