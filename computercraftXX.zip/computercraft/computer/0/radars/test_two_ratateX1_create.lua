local side = "top" -- Укажите вашу сторону блока
local m = peripheral.wrap(side)

if not m then
    print("Block not found!")
    return
end

-- m.move(1, 10)
-- os.sleep(1)
-- m.move(2, 20)
-- os.sleep(1)
--m.rotate(50, 3)
-- m.move(2, 5)
-- os.sleep(3)
--m.rotate(50, 1)

-- test ok
-- for i = -2, 2 do
    -- print("Number: " .. i)
	-- --m.move(1, i)
	-- m.rotate(50, i)
	-- os.sleep(2)
-- end

os.sleep(2)
m.rotate(150, 2)
os.sleep(2)
m.rotate(150, -2)

-- print("=== TESTING DIRECTION WITH 2 ARGUMENTS ===")

-- -- Тест 1: Движение с флагом 1
-- print("\n1. Testing move(5, 1)...")
-- m.move(50, 1)
-- os.sleep(1)
-- print("Is running: " .. tostring(m.isRunning()))

-- -- Тест 2: Движение с флагом -1 (Проверяем реверс!)
-- print("\n2. Testing move(5, -1)...")
-- m.move(50, 3)
-- os.sleep(1)
-- print("Is running: " .. tostring(m.isRunning()))

-- -- -- Тест 3: Вращение с флагом 1
-- -- print("\n3. Testing rotate(45, 1)...")
-- -- local ok1, err1 = pcall(m.rotate, 45, 1)
-- -- if ok1 then os.sleep(3) else print("Error: " .. tostring(err1)) end

-- -- -- Тест 4: Вращение с флагом -1 (Проверяем реверс вращения!)
-- -- print("\n4. Testing rotate(45, -1)...")
-- -- local ok2, err2 = pcall(m.rotate, 45, -1)
-- -- if ok2 then os.sleep(3) else print("Error: " .. tostring(err2)) end

-- print("\n=== TEST END ===")
