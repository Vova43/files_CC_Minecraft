local side = "top" -- Укажите сторону блока
local m = peripheral.wrap(side)

if not m then
    print("Block not found on side: " .. side)
    return
end

print("=== STARTING MOVEMENT TEST ===")
print("Is block running now?: " .. tostring(m.isRunning()))

-- Тест 1: Пробуем маленькое значение (например, 1 или 10)
print("\nSending command: rotate(5)")
m.rotate(50)
os.sleep(2)
print("Is running?: " .. tostring(m.isRunning()))

-- Тест 2: Пробуем отрицательное значение для реверса
print("\nSending command: rotate(-5)")
m.rotate(-50)
os.sleep(2)
print("Is running?: " .. tostring(m.isRunning()))

-- Тест 3: Пробуем остановить (обычно это 0)
print("\nSending command: rotate(0)")
m.rotate(0)
os.sleep(1)
print("Is running?: " .. tostring(m.isRunning()))
