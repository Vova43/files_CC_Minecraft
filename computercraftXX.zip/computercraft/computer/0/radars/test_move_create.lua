local side = "top" -- Укажите сторону, где стоит этот блок
local m = peripheral.wrap(side)

if not m then
    print("Block not found on side: " .. side)
    return
end

print("=== STARTING MOVE TEST ===")
print("Is block running now?: " .. tostring(m.isRunning()))

-- Тест 1: Пробуем движение вперед / вверх
print("\nSending command: move(5)")
m.move(5)
os.sleep(3) -- Ждем 3 секунды, смотрим на блок в игре
print("Is running?: " .. tostring(m.isRunning()))

-- Тест 2: Пробуем обратное движение (реверс)
print("\nSending command: move(-5)")
m.move(-5)
os.sleep(3) -- Ждем 3 секунды
print("Is running?: " .. tostring(m.isRunning()))

-- Тест 3: Пробуем принудительную остановку
print("\nSending command: move(0)")
m.move(0)
os.sleep(1)
print("Final status. Is running?: " .. tostring(m.isRunning()))
