local side = "top" -- Укажите сторону вашего блока
local m = peripheral.wrap(side)

if not m then
    print("Block not found!")
    return
end

print("=== DEEP MOVE & REVERSE TEST ===")

-- Тест 1: Проверяем, почему не работает отрицательное число
print("\n1. Testing move(-5)...")
local success, err = pcall(m.move, -5)
if not success then
    print("Error caught: " .. tostring(err))
else
    print("Executed without Lua error, but block ignored it or can't go back.")
end

-- Тест 2: Пробуем передать два аргумента (например, дистанция и направление/скорость)
print("\n2. Testing move(5, -1) [Two arguments]...")
local success2, err2 = pcall(m.move, 5, -1)
if success2 then
    print("Success! Two arguments accepted.")
else
    print("Two arguments failed: " .. tostring(err2))
end

-- Тест 3: Проверяем, как работал прошлый тест rotate(5) и rotate(-5)
print("\n3. Testing rotate(-5)...")
local success3, err3 = pcall(m.rotate, -5)
if not success3 then
    print("Rotate error: " .. tostring(err3))
else
    print("Rotate executed. Did it change direction?")
end
