local side = "top"
local filename = "peripheral_log4.txt"

local p = peripheral.wrap(side)
if not p then
    print("Peripheral not found on side: " .. side)
    return
end

local file = fs.open(filename, "w")
if not file then
    print("Error: Could not create file " .. filename)
    return
end

local function log(text)
    print(text)
    file.writeLine(text)
end

local blockType = peripheral.getType(side)
log(string.format("--- Connected: %s (Type: %s) ---", side:upper(), tostring(blockType)))

-- Рекурсивная сериализация таблиц любой глубины с отступами
local function serializeTable(tbl, indent)
    indent = indent or 0
    local space = string.rep("  ", indent)
    local items = {}
    
    for k, v in pairs(tbl) do
        local keyStr = type(k) == "number" and string.format("[%d]", k) or string.format('["%s"]', tostring(k))
        local valStr
        
        if type(v) == "string" then
            valStr = string.format('"%s"', v)
        elseif type(v) == "table" then
            valStr = serializeTable(v, indent + 1) -- Рекурсивно раскрываем вложенные таблицы
        else
            valStr = tostring(v)
        end
        
        table.insert(items, string.format("%s  %s = %s", space, keyStr, valStr))
    end
    
    if #items == 0 then
        return "{}"
    end
    
    return "{\n" .. table.concat(items, ",\n") .. "\n" .. space .. "}"
end

local function formatResult(res)
    if type(res) == "table" then
        return serializeTable(res)
    else
        return tostring(res)
    end
end

-- Функция для умного вызова методов (включая попытку подбора базовых аргументов)
local function tryCallMethod(fn)
    -- Попытка 1: Без аргументов
    local ok, res = pcall(fn)
    if ok then return formatResult(res) end
    
    -- Попытка 2: Пробуем передать число 1 (часто нужно для индексов, ID треков, слотов)
    local okNum, resNum = pcall(fn, 1)
    if okNum then return "[Arg: 1] -> " .. formatResult(resNum) end
    
    -- Попытка 3: Пробуем передать пустую строку
    local okStr, resStr = pcall(fn, "")
    if okStr then return "[Arg: \"\"] -> " .. formatResult(resStr) end
    
    -- Если ничего не подошло, возвращаем исходную ошибку для понимания, что метод ждет
    return "(requires arguments: " .. tostring(res):gsub("^.-:%d+: ", "") .. ")"
end

local seen = {}

local function inspect(obj, prefix)
    prefix = prefix or ""
    if seen[obj] then return end
    seen[obj] = true
    
    for k, v in pairs(obj) do
        local fullName = prefix == "" and k or (prefix .. "." .. k)
        local vType = type(v)
        
        if vType == "function" then
            log(string.format("[Method] %s -> %s", fullName, tryCallMethod(v)))
        elseif vType == "table" then
            log(string.format("[Table ] %s = %s", fullName, serializeTable(v)))
            if not seen[v] then
                inspect(v, fullName)
            end
        else
            log(string.format("[Field ] %s = %s (%s)", fullName, formatResult(v), vType))
        end
    end
end

log("--- Standard Peripheral Methods ---")
local methods = peripheral.getMethods(side)
if methods then
    for _, name in ipairs(methods) do
        local fn = p[name]
        if type(fn) == "function" then
            log(string.format("  %s -> %s", name, tryCallMethod(fn)))
        end
    end
end

log("\n--- Full Object Scan ---")
inspect(p)


log("\nDone! Results saved to " .. filename)
file.close()