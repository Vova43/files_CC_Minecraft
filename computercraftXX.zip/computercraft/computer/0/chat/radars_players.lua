local radar_side = "back"
local chat_side = "top"
local list_file = "players.txt"

local radar = peripheral.wrap(radar_side)
local chat = peripheral.wrap(chat_side)

if not radar or not chat then
    print("Error: Check radar and chat box connections!")
    return
end

-- Функция загрузки списка ников из файла
local function loadPlayerList()
    local names = {}
    if not fs.exists(list_file) then
        -- Если файла нет, создаем шаблон с вашим ником
        local f = fs.open(list_file, "w")
        f.writeLine("Vova43")
        f.close()
        return { "Vova43" }
    end
    
    local f = fs.open(list_file, "r")
    local line = f.readLine()
    while line do
        -- Убираем лишние пробелы
        line = line:gsub("%s+", "")
        if line ~= "" then
            table.insert(names, line)
        end
        line = f.readLine()
    end
    f.close()
    return names
end

-- Функция поиска онлайн-игроков методом "тихой отправки" сообщения
local function getOnlineTrackedPlayers(player_pool)
    local online = {}
    for _, name in ipairs(player_pool) do
        -- Отправляем пустое сообщение. Игрок его не увидит, но метод вернет true/false
        local success, result = pcall(chat.sendMessageToPlayer, "", name)
        if success and result == true then
            online[name] = true
        end
    end
    return online
end

print("Loading local player dictionary...")
local player_pool = loadPlayerList()

print("Scanning for targets...")
local tracks = radar.getTracks()
local online_status = getOnlineTrackedPlayers(player_pool)

if tracks then
    local player_index = 1
    for _, entity in ipairs(tracks) do
        if entity.category == "PLAYER" then
            print("\n[Target Spotted]")
            print("UUID: " .. entity.id)
            print(string.format("Pos: X: %.1f, Y: %.1f, Z: %.1f", entity.position.x, entity.position.y, entity.position.z))
            
            -- Пытаемся сопоставить онлайн игроков из файла с целями на радаре
            local matched_name = "Unknown Player"
            
            -- Метод подбора: если в сети только один человек из файла, и радар видит одного игрока
            -- Либо если мы сопоставим по базе. В данном случае выводим список тех, кто онлайн на базе
            local online_list = {}
            for name, _ in pairs(online_status) do
                table.insert(online_list, name)
            end
            
            if #online_list == 1 then
                matched_name = online_list[1]
            elseif #online_list > 1 then
                matched_name = online_list[player_index] or "Multiple Players Online"
                player_index = player_index + 1
            end
            
            print("Guessed Nickname: " .. matched_name)
        end
    end
else
    print("Radar ranges are clear.")
end
