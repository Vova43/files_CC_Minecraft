--[[
local w, h = term.getSize()
local leftFiles = fs.list("")
local rightFiles = fs.list("")
local activePanel = "left" -- какая панель активна: "left" или "right"
local leftSel, rightSel = 1, 1 -- выбранные файлы в панелях

-- Функция отрисовки рамки и списков
local function draw()
    term.clear()
    local mid = math.floor(w / 2)
    
    -- Рисуем разделитель панелей
    for y = 1, h - 2 do
        term.setCursorPos(mid, y)
        term.write("|")
    end
    
    -- Отрисовка левой панели
    for i, file in ipairs(leftFiles) do
        term.setCursorPos(2, i)
        if activePanel == "left" and i == leftSel then
            term.setBackgroundColor(colors.blue) -- подсвечиваем курсор
        else
            term.setBackgroundColor(colors.black)
        end
        term.write(file:sub(1, mid - 3))
    end
    
    -- Отрисовка правой панели
    for i, file in ipairs(rightFiles) do
        term.setCursorPos(mid + 2, i)
        if activePanel == "right" and i == rightSel then
            term.setBackgroundColor(colors.blue)
        else
            term.setBackgroundColor(colors.black)
        end
        term.write(file:sub(1, mid - 3))
    end
    
    -- Нижняя панель подсказок (как в DOS)
    term.setBackgroundColor(colors.gray)
    term.setCursorPos(1, h)
    term.clearLine()
    term.write(" Tab: Смена панели | Up/Down: Навигация | Q: Выход")
    term.setBackgroundColor(colors.black)
end

-- Главный цикл программы
while true do
    draw()
    local event, key = os.pullEvent("key")
    
    if key == keys.q then -- Выход
        term.clear()
        term.setCursorPos(1,1)
        break
    elseif key == keys.tab then -- Переключение панелей
        if activePanel == "left" then activePanel = "right" else activePanel = "left" end
    elseif key == keys.up then -- Вверх
        if activePanel == "left" and leftSel > 1 then leftSel = leftSel - 1
        elseif activePanel == "right" and rightSel > 1 then rightSel = rightSel - 1 end
    elseif key == keys.down then -- Вниз
        if activePanel == "left" and leftSel < #leftFiles then leftSel = leftSel + 1
        elseif activePanel == "right" and rightSel < #rightFiles then rightSel = rightSel + 1 end
    end
end
....

local w, h = term.getSize()
local leftFiles = fs.list("")
local rightFiles = fs.list("")
local activePanel = "left" -- active panel: "left" or "right"
local leftSel, rightSel = 1, 1 -- selected files in panels

-- Function to draw the frames and lists
local function draw()
    term.clear()
    local mid = math.floor(w / 2)

    -- Draw the panel separator
    for y = 1, h - 2 do
        term.setCursorPos(mid, y)
        term.write("|")
    end

    -- Draw the left panel
    for i, file in ipairs(leftFiles) do
        term.setCursorPos(2, i)
        if activePanel == "left" and i == leftSel then
            term.setBackgroundColor(colors.blue) -- highlight the cursor
        else
            term.setBackgroundColor(colors.black)
        end
        term.write(file:sub(1, mid - 3))
    end

    -- Draw the right panel
    for i, file in ipairs(rightFiles) do
        term.setCursorPos(mid + 2, i)
        if activePanel == "right" and i == rightSel then
            term.setBackgroundColor(colors.blue)
        else
            term.setBackgroundColor(colors.black)
        end
        term.write(file:sub(1, mid - 3))
    end

    -- Bottom hint bar (DOS-like)
    term.setBackgroundColor(colors.gray)
    term.setCursorPos(1, h)
    term.clearLine()
    term.write(" Tab: Switch Panel | Up/Down: Navigate | Q: Exit")
    term.setBackgroundColor(colors.black)
end

-- Main program loop
while true do
    draw()
    local event, key = os.pullEvent("key")

    if key == keys.q then -- Exit
        term.clear()
        term.setCursorPos(1,1)
        break
    elseif key == keys.tab then -- Switch panels
        if activePanel == "left" then
            activePanel = "right"
        else
            activePanel = "left"
        end
    elseif key == keys.up then -- Up
        if activePanel == "left" and leftSel > 1 then
            leftSel = leftSel - 1
        elseif activePanel == "right" and rightSel > 1 then
            rightSel = rightSel - 1
        end
    elseif key == keys.down then -- Down
        if activePanel == "left" and leftSel < #leftFiles then
            leftSel = leftSel + 1
        elseif activePanel == "right" and rightSel < #rightFiles then
            rightSel = rightSel + 1
        end
    end
end
--


local w, h = term.getSize()

-- Store current paths and file lists for both panels
local leftDir, rightDir = "", ""
local leftFiles = fs.list(leftDir)
local rightFiles = fs.list(rightDir)

local activePanel = "left"
local leftSel, rightSel = 1, 1
local showHelp = false -- Flag to toggle the help window

-- Function to refresh the file list in a specific panel
local function refreshPanel(panel)
    if panel == "left" then
        leftFiles = fs.list(leftDir)
        if leftSel > #leftFiles then leftSel = math.max(1, #leftFiles) end
    else
        rightFiles = fs.list(rightDir)
        if rightSel > #rightFiles then rightSel = math.max(1, #rightFiles) end
    end
end

-- Helper function to draw a single panel's file list
local function drawPanelList(files, currentDir, startX, mid, isActive, currentSel)
    for i, file in ipairs(files) do
        if i > h - 3 then break end -- Prevent drawing outside screen boundaries
        term.setCursorPos(startX, i + 1)
        
        -- Get full path to check if the item is a directory
        local fullPath = fs.combine(currentDir, file)
        
        -- Set background color (highlight active selection)
        if isActive and i == currentSel then
            term.setBackgroundColor(colors.blue)
        else
            term.setBackgroundColor(colors.black)
        end
        
        -- Set text color (directories are highlighted in yellow)
        if fs.isDir(fullPath) then
            term.setTextColor(colors.yellow)
        else
            term.setTextColor(colors.white)
        end
        
        -- Truncate or pad file name to fit the panel perfectly
        term.write(file:sub(1, mid - 3) .. string.rep(" ", (mid - 3) - #file))
    end
    term.setTextColor(colors.white) -- Reset text color
end

-- Function to draw the help window overlay
local function drawHelpWindow()
    local hw, hh = 34, 10
    local sx = math.floor((w - hw) / 2)
    local sy = math.floor((h - hh) / 2)
    
    term.setBackgroundColor(colors.gray)
    for y = sy, sy + hh do
        term.setCursorPos(sx, y)
        term.write(string.rep(" ", hw))
    end
    
    term.setTextColor(colors.yellow)
    term.setCursorPos(sx + 14, sy + 1)
    term.write("HELP")
    
    term.setTextColor(colors.white)
    term.setCursorPos(sx + 2, sy + 3) term.write("Tab       - Switch panel")
    term.setCursorPos(sx + 2, sy + 4) term.write("Enter     - Open folder")
    term.setCursorPos(sx + 2, sy + 5) term.write("Backspace - Go back (up)")
    term.setCursorPos(sx + 2, sy + 6) term.write("C         - Copy to other panel")
    term.setCursorPos(sx + 2, sy + 7) term.write("H         - Close help")
    term.setCursorPos(sx + 2, sy + 8) term.write("Q         - Exit program")
end

-- Main draw function
local function draw()
    term.clear()
    local mid = math.floor(w / 2)
    
    -- Draw path headers at the top of the panels
    term.setBackgroundColor(colors.gray)
    term.setCursorPos(1, 1)
    term.clearLine()
    term.setCursorPos(2, 1) term.write("/" .. leftDir)
    term.setCursorPos(mid + 2, 1) term.write("/" .. rightDir)
    term.setBackgroundColor(colors.black)
    
    -- Draw panel separator line
    for y = 2, h - 2 do
        term.setCursorPos(mid, y)
        term.write("|")
    end
    
    -- Draw file lists for both panels
    drawPanelList(leftFiles, leftDir, 2, mid, (activePanel == "left"), leftSel)
    drawPanelList(rightFiles, rightDir, mid + 2, mid, (activePanel == "right"), rightSel)
    
    -- Bottom shortcut hint bar
    term.setBackgroundColor(colors.gray)
    term.setCursorPos(1, h)
    term.clearLine()
    --term.write(" Tab:Panel | Enter:Open | Backspace:Back | C:Copy | H:Help")
    term.setBackgroundColor(colors.black)
    
    -- Draw the help window overlay if active
    if showHelp then
        drawHelpWindow()
    end
end

-- Main program loop
while true do
    draw()
    local event, key = os.pullEvent("key")
    
    if showHelp then
        -- If help is open, only respond to closing it or exiting
        if key == keys.h then
            showHelp = false
        elseif key == keys.q then
            break
        end
    else
        -- Normal navigation mode
        if key == keys.q then
            break
        elseif key == keys.h then
            showHelp = true
        elseif key == keys.tab then
            activePanel = (activePanel == "left") and "right" or "left"
        elseif key == keys.up then
            if activePanel == "left" and leftSel > 1 then leftSel = leftSel - 1
            elseif activePanel == "right" and rightSel > 1 then rightSel = rightSel - 1 end
        elseif key == keys.down then
            if activePanel == "left" and leftSel < #leftFiles then leftSel = leftSel + 1
            elseif activePanel == "right" and rightSel < #rightFiles then rightSel = rightSel + 1 end
            
        elseif key == keys.enter then
            -- Enter folder
            if activePanel == "left" and #leftFiles > 0 then
                local selected = leftFiles[leftSel]
                local fullPath = fs.combine(leftDir, selected)
                if fs.isDir(fullPath) then
                    leftDir = fullPath
                    leftSel = 1
                    refreshPanel("left")
                end
            elseif activePanel == "right" and #rightFiles > 0 then
                local selected = rightFiles[rightSel]
                local fullPath = fs.combine(rightDir, selected)
                if fs.isDir(fullPath) then
                    rightDir = fullPath
                    rightSel = 1
                    refreshPanel("right")
                end
            end
            
        elseif key == keys.backspace then
            -- Go back to parent directory
            if activePanel == "left" and leftDir ~= "" then
                leftDir = fs.getDir(leftDir)
                leftSel = 1
                refreshPanel("left")
            elseif activePanel == "right" and rightDir ~= "" then
                rightDir = fs.getDir(rightDir)
                rightSel = 1
                refreshPanel("right")
            end
            
        elseif key == keys.c then
            -- Copy file/folder to the opposite panel
            if activePanel == "left" and #leftFiles > 0 then
                local source = fs.combine(leftDir, leftFiles[leftSel])
                local dest = fs.combine(rightDir, leftFiles[leftSel])
                if not fs.exists(dest) then -- Prevent accidental overwrite
                    fs.copy(source, dest)
                    refreshPanel("right")
                end
            elseif activePanel == "right" and #rightFiles > 0 then
                local source = fs.combine(rightDir, rightFiles[rightSel])
                local dest = fs.combine(leftDir, rightFiles[rightSel])
                if not fs.exists(dest) then
                    fs.copy(source, dest)
                    refreshPanel("left")
                end
            end
        end
    end
end

-- Clean up screen on exit
term.clear()
term.setCursorPos(1,1)
--

local w, h = term.getSize()

-- Store current paths and file lists for both panels
local leftDir, rightDir = "", ""
local leftFiles = fs.list(leftDir)
local rightFiles = fs.list(rightDir)

local activePanel = "left"
local leftSel, rightSel = 1, 1
local showHelp = false -- Flag to toggle the help window

-- Function to refresh the file list in a specific panel
local function refreshPanel(panel)
    if panel == "left" then
        leftFiles = fs.list(leftDir)
        if leftSel > #leftFiles then leftSel = math.max(1, #leftFiles) end
    else
        rightFiles = fs.list(rightDir)
        if rightSel > #rightFiles then rightSel = math.max(1, #rightFiles) end
    end
end

-- Helper function to draw a single panel's file list
local function drawPanelList(files, currentDir, startX, mid, isActive, currentSel)
    for i, file in ipairs(files) do
        if i > h - 3 then break end -- Prevent drawing outside screen boundaries
        term.setCursorPos(startX, i + 1)
        
        -- Get full path to check if the item is a directory
        local fullPath = fs.combine(currentDir, file)
        
        -- Set background color (highlight active selection)
        if isActive and i == currentSel then
            term.setBackgroundColor(colors.blue)
        else
            term.setBackgroundColor(colors.black)
        end
        
        -- Set text color (directories are highlighted in yellow)
        if fs.isDir(fullPath) then
            term.setTextColor(colors.yellow)
        else
            term.setTextColor(colors.white)
        end
        
        -- Truncate or pad file name to fit the panel perfectly
        term.write(file:sub(1, mid - 3) .. string.rep(" ", (mid - 3) - #file))
    end
    term.setTextColor(colors.white) -- Reset text color
end

-- Function to draw the help window overlay
local function drawHelpWindow()
    local hw, hh = 34, 11
    local sx = math.floor((w - hw) / 2)
    local sy = math.floor((h - hh) / 2)
    
    term.setBackgroundColor(colors.gray)
    for y = sy, sy + hh do
        term.setCursorPos(sx, y)
        term.write(string.rep(" ", hw))
    end
    
    term.setTextColor(colors.yellow)
    term.setCursorPos(sx + 14, sy + 1)
    term.write("HELP")
    
    term.setTextColor(colors.white)
    term.setCursorPos(sx + 2, sy + 3) term.write("Tab       - Switch panel")
    term.setCursorPos(sx + 2, sy + 4) term.write("Enter     - Open folder / file")
    term.setCursorPos(sx + 2, sy + 5) term.write("Backspace - Go back (up)")
    term.setCursorPos(sx + 2, sy + 6) term.write("C         - Copy to other panel")
    term.setCursorPos(sx + 2, sy + 7) term.write("H         - Close help")
    term.setCursorPos(sx + 2, sy + 8) term.write("Q         - Exit program")
end

-- Main draw function
local function draw()
    term.clear()
    local mid = math.floor(w / 2)
    
    -- Draw path headers at the top of the panels
    term.setBackgroundColor(colors.gray)
    term.setCursorPos(1, 1)
    term.clearLine()
    term.setCursorPos(2, 1) term.write("/" .. leftDir)
    term.setCursorPos(mid + 2, 1) term.write("/" .. rightDir)
    term.setBackgroundColor(colors.black)
    
    -- Draw panel separator line
    for y = 2, h - 2 do
        term.setCursorPos(mid, y)
        term.write("|")
    end
    
    -- Draw file lists for both panels
    drawPanelList(leftFiles, leftDir, 2, mid, (activePanel == "left"), leftSel)
    drawPanelList(rightFiles, rightDir, mid + 2, mid, (activePanel == "right"), rightSel)
    
    -- Bottom shortcut hint bar
    term.setBackgroundColor(colors.gray)
    term.setCursorPos(1, h)
    term.clearLine()
    --term.write(" Tab:Panel | Enter:Open | Backspace:Back | C:Copy | H:Help")
    term.setBackgroundColor(colors.black)
    
    -- Draw the help window overlay if active
    if showHelp then
        drawHelpWindow()
    end
end

-- Main program loop
while true do
    draw()
    local event, key = os.pullEvent("key")
    
    if showHelp then
        -- If help is open, only respond to closing it or exiting
        if key == keys.h then
            showHelp = false
        elseif key == keys.q then
            break
        end
    else
        -- Normal navigation mode
        if key == keys.q then
            break
        elseif key == keys.h then
            showHelp = true
        elseif key == keys.tab then
            activePanel = (activePanel == "left") and "right" or "left"
        elseif key == keys.up then
            if activePanel == "left" and leftSel > 1 then leftSel = leftSel - 1
            elseif activePanel == "right" and rightSel > 1 then rightSel = rightSel - 1 end
        elseif key == keys.down then
            if activePanel == "left" and leftSel < #leftFiles then leftSel = leftSel + 1
            elseif activePanel == "right" and rightSel < #rightFiles then rightSel = rightSel + 1 end
            
        elseif key == keys.enter then
            -- Handle Enter: Open folder OR open file in edit
            local currentDir = (activePanel == "left") and leftDir or rightDir
            local currentFiles = (activePanel == "left") and leftFiles or rightFiles
            local currentSel = (activePanel == "left") and leftSel or rightSel
            
            if #currentFiles > 0 then
                local selected = currentFiles[currentSel]
                local fullPath = fs.combine(currentDir, selected)
                
                if fs.isDir(fullPath) then
                    -- If it's a directory, enter it
                    if activePanel == "left" then
                        leftDir = fullPath
                        leftSel = 1
                        refreshPanel("left")
                    else
                        rightDir = fullPath
                        rightSel = 1
                        refreshPanel("right")
                    end
                else
                    -- If it's a file, open in built-in text editor
                    term.clear()
                    term.setCursorPos(1, 1)
                    shell.run("edit", fullPath)
                    
                    -- Refresh both panels in case the file was modified/deleted
                    refreshPanel("left")
                    refreshPanel("right")
                end
            end
            
        elseif key == keys.backspace then
            -- Go back to parent directory
            if activePanel == "left" and leftDir ~= "" then
                leftDir = fs.getDir(leftDir)
                leftSel = 1
                refreshPanel("left")
            elseif activePanel == "right" and rightDir ~= "" then
                rightDir = fs.getDir(rightDir)
                rightSel = 1
                refreshPanel("right")
            end
            
        elseif key == keys.c then
            -- Copy file/folder to the opposite panel
            if activePanel == "left" and #leftFiles > 0 then
                local source = fs.combine(leftDir, leftFiles[leftSel])
                local dest = fs.combine(rightDir, leftFiles[leftSel])
                if not fs.exists(dest) then -- Prevent accidental overwrite
                    fs.copy(source, dest)
                    refreshPanel("right")
                end
            elseif activePanel == "right" and #rightFiles > 0 then
                local source = fs.combine(rightDir, rightFiles[rightSel])
                local dest = fs.combine(leftDir, rightFiles[rightSel])
                if not fs.exists(dest) then
                    fs.copy(source, dest)
                    refreshPanel("left")
                end
            end
        end
    end
end

-- Clean up screen on exit
term.clear()
term.setCursorPos(1,1)

--

local w, h = term.getSize()

-- Store current paths and file lists for both panels
local leftDir, rightDir = "", ""
local leftFiles = fs.list(leftDir)
local rightFiles = fs.list(rightDir)

local activePanel = "left"
local leftSel, rightSel = 1, 1
local showHelp = false -- Flag to toggle the help window

-- Function to refresh the file list in a specific panel
local function refreshPanel(panel)
    if panel == "left" then
        leftFiles = fs.list(leftDir)
        if leftSel > #leftFiles then leftSel = math.max(1, #leftFiles) end
    else
        rightFiles = fs.list(rightDir)
        if rightSel > #rightFiles then rightSel = math.max(1, #rightFiles) end
    end
end

-- Helper function to draw a single panel's file list
local function drawPanelList(files, currentDir, startX, mid, isActive, currentSel)
    for i, file in ipairs(files) do
        if i > h - 3 then break end -- Prevent drawing outside screen boundaries
        term.setCursorPos(startX, i + 1)
        
        -- Get full path to check if the item is a directory
        local fullPath = fs.combine(currentDir, file)
        
        -- Set background color (highlight active selection)
        if isActive and i == currentSel then
            term.setBackgroundColor(colors.blue)
        else
            term.setBackgroundColor(colors.black)
        end
        
        -- Set text color (directories are highlighted in yellow)
        if fs.isDir(fullPath) then
            term.setTextColor(colors.yellow)
        else
            term.setTextColor(colors.white)
        end
        
        -- Truncate or pad file name to fit the panel perfectly
        term.write(file:sub(1, mid - 3) .. string.rep(" ", (mid - 3) - #file))
    end
    term.setTextColor(colors.white) -- Reset text color
end

-- Function to draw the help window overlay
local function drawHelpWindow()
    local hw, hh = 34, 11
    local sx = math.floor((w - hw) / 2)
    local sy = math.floor((h - hh) / 2)
    
    term.setBackgroundColor(colors.gray)
    for y = sy, sy + hh do
        term.setCursorPos(sx, y)
        term.write(string.rep(" ", hw))
    end
    
    term.setTextColor(colors.yellow)
    term.setCursorPos(sx + 14, sy + 1)
    term.write("HELP")
    
    term.setTextColor(colors.white)
    term.setCursorPos(sx + 2, sy + 3) term.write("Tab       - Switch panel")
    term.setCursorPos(sx + 2, sy + 4) term.write("Enter     - Open folder / file")
    term.setCursorPos(sx + 2, sy + 5) term.write("Backspace - Go back (up)")
    term.setCursorPos(sx + 2, sy + 6) term.write("C         - Copy to other panel")
    term.setCursorPos(sx + 2, sy + 7) term.write("M         - Move to other panel")
    term.setCursorPos(sx + 2, sy + 8) term.write("H         - Close help")
    term.setCursorPos(sx + 2, sy + 9) term.write("Q         - Exit program")
end

-- Main draw function
local function draw()
    term.clear()
    local mid = math.floor(w / 2)
    
    -- Draw path headers at the top of the panels
    term.setBackgroundColor(colors.gray)
    term.setCursorPos(1, 1)
    term.clearLine()
    term.setCursorPos(2, 1) term.write("/" .. leftDir)
    term.setCursorPos(mid + 2, 1) term.write("/" .. rightDir)
    term.setBackgroundColor(colors.black)
    
    -- Draw panel separator line
    for y = 2, h - 2 do
        term.setCursorPos(mid, y)
        term.write("|")
    end
    
    -- Draw file lists for both panels
    drawPanelList(leftFiles, leftDir, 2, mid, (activePanel == "left"), leftSel)
    drawPanelList(rightFiles, rightDir, mid + 2, mid, (activePanel == "right"), rightSel)
    
    -- Dynamic bottom shortcut hint bar
    term.setBackgroundColor(colors.gray)
    term.setCursorPos(1, h)
    term.clearLine()
    
    -- Calculate paths for the live preview text
    local activeDir = (activePanel == "left") and leftDir or rightDir
    local activeFiles = (activePanel == "left") and leftFiles or rightFiles
    local activeSel = (activePanel == "left") and leftSel or rightSel
    local targetDir = (activePanel == "left") and rightDir or leftDir
    
    if #activeFiles > 0 then
        local currentFile = activeFiles[activeSel]
        local fromPath = "/" .. fs.combine(activeDir, currentFile)
        local toPath = "/" .. fs.combine(targetDir, currentFile)
        
        -- Truncate message if it exceeds screen width
        local msg = " move: " .. fromPath .. " to " .. toPath
        term.write(msg:sub(1, w))
    else
        term.write(" [Empty Panel] - Press H for Help")
    end
    
    term.setBackgroundColor(colors.black)
    
    -- Draw the help window overlay if active
    if showHelp then
        drawHelpWindow()
    end
end

-- Main program loop
while true do
    draw()
    local event, key = os.pullEvent("key")
    
    if showHelp then
        -- If help is open, only respond to closing it or exiting
        if key == keys.h then
            showHelp = false
        elseif key == keys.q then
            break
        end
    else
        -- Normal navigation mode
        if key == keys.q then
            break
        elseif key == keys.h then
            showHelp = true
        elseif key == keys.tab then
            activePanel = (activePanel == "left") and "right" or "left"
        elseif key == keys.up then
            if activePanel == "left" and leftSel > 1 then leftSel = leftSel - 1
            elseif activePanel == "right" and rightSel > 1 then rightSel = rightSel - 1 end
        elseif key == keys.down then
            if activePanel == "left" and leftSel < #leftFiles then leftSel = leftSel + 1
            elseif activePanel == "right" and rightSel < #rightFiles then rightSel = rightSel + 1 end
            
        elseif key == keys.enter then
            -- Handle Enter: Open folder OR open file in edit
            local currentDir = (activePanel == "left") and leftDir or rightDir
            local currentFiles = (activePanel == "left") and leftFiles or rightFiles
            local currentSel = (activePanel == "left") and leftSel or rightSel
            
            if #currentFiles > 0 then
                local selected = currentFiles[currentSel]
                local fullPath = fs.combine(currentDir, selected)
                
                if fs.isDir(fullPath) then
                    -- If it's a directory, enter it
                    if activePanel == "left" then
                        leftDir = fullPath
                        leftSel = 1
                        refreshPanel("left")
                    else
                        rightDir = fullPath
                        rightSel = 1
                        refreshPanel("right")
                    end
                else
                    -- If it's a file, open in built-in text editor
                    term.clear()
                    term.setCursorPos(1, 1)
                    shell.run("edit", fullPath)
                    
                    -- Refresh both panels in case the file was modified/deleted
                    refreshPanel("left")
                    refreshPanel("right")
                end
            end
            
        elseif key == keys.backspace then
            -- Go back to parent directory
            if activePanel == "left" and leftDir ~= "" then
                leftDir = fs.getDir(leftDir)
                leftSel = 1
                refreshPanel("left")
            elseif activePanel == "right" and rightDir ~= "" then
                rightDir = fs.getDir(rightDir)
                rightSel = 1
                refreshPanel("right")
            end
            
        elseif key == keys.c then
            -- Copy file/folder to the opposite panel
            if activePanel == "left" and #leftFiles > 0 then
                local source = fs.combine(leftDir, leftFiles[leftSel])
                local dest = fs.combine(rightDir, leftFiles[leftSel])
                if not fs.exists(dest) then -- Prevent accidental overwrite
                    fs.copy(source, dest)
                    refreshPanel("right")
                end
            elseif activePanel == "right" and #rightFiles > 0 then
                local source = fs.combine(rightDir, rightFiles[rightSel])
                local dest = fs.combine(leftDir, rightFiles[rightSel])
                if not fs.exists(dest) then
                    fs.copy(source, dest)
                    refreshPanel("left")
                end
            end
            
        elseif key == keys.m then
            -- Move file/folder to the opposite panel
            if activePanel == "left" and #leftFiles > 0 then
                local source = fs.combine(leftDir, leftFiles[leftSel])
                local dest = fs.combine(rightDir, leftFiles[leftSel])
                if not fs.exists(dest) then -- Prevent accidental overwrite
                    fs.move(source, dest)
                    refreshPanel("left")
                    refreshPanel("right")
                end
            elseif activePanel == "right" and #rightFiles > 0 then
                local source = fs.combine(rightDir, rightFiles[rightSel])
                local dest = fs.combine(leftDir, rightFiles[rightSel])
                if not fs.exists(dest) then
                    fs.move(source, dest)
                    refreshPanel("left")
                    refreshPanel("right")
                end
            end
        end
    end
end

-- Clean up screen on exit
term.clear()
term.setCursorPos(1,1)
--


local w, h = term.getSize()

-- Текущие пути и списки файлов
local leftDir, rightDir = "", ""
local leftFiles = fs.list(leftDir)
local rightFiles = fs.list(rightDir)

local activePanel = "left"
local leftSel, rightSel = 1, 1
local showHelp = false

-- Таблицы для хранения выделенных файлов (хранят имя файла = true)
local leftSelected, rightSelected = {}, {}

-- Функция сброса выделения при переходе в другую папку
local function clearSelection(panel)
    if panel == "left" then leftSelected = {} else rightSelected = {} end
end

-- Функция подсчета количества выделенных файлов
local function getSelectedCount(selectedTable)
    local count = 0
    for _ in pairs(selectedTable) do count = count + 1 end
    return count
end

-- Обновление списков файлов
local function refreshPanel(panel)
    if panel == "left" then
        leftFiles = fs.list(leftDir)
        if leftSel > #leftFiles then leftSel = math.max(1, #leftFiles) end
    else
        rightFiles = fs.list(rightDir)
        if rightSel > #rightFiles then rightSel = math.max(1, #rightFiles) end
    end
end

-- Отрисовка списка панели
local function drawPanelList(files, currentDir, startX, mid, isActive, currentSel, selectedTable)
    for i, file in ipairs(files) do
        if i > h - 3 then break end
        term.setCursorPos(startX, i + 1)
        
        local fullPath = fs.combine(currentDir, file)
        
        -- Логика цветов фона
        if isActive and i == currentSel then
            term.setBackgroundColor(colors.blue) -- синий курсор
        elseif selectedTable[file] then
            term.setBackgroundColor(colors.green) -- зеленый цвет для выделенных файлов
        else
            term.setBackgroundColor(colors.black)
        end
        
        -- Цвет текста (папки - желтые, файлы - белые)
        if fs.isDir(fullPath) then
            term.setTextColor(colors.yellow)
        else
            term.setTextColor(colors.white)
        end
        
        term.write(file:sub(1, mid - 3) .. string.rep(" ", (mid - 3) - #file))
    end
    term.setTextColor(colors.white)
end

-- Справка
local function drawHelpWindow()
    local hw, hh = 34, 12
    local sx = math.floor((w - hw) / 2)
    local sy = math.floor((h - hh) / 2)
    
    term.setBackgroundColor(colors.gray)
    for y = sy, sy + hh do term.setCursorPos(sx, y) term.write(string.rep(" ", hw)) end
    
    term.setTextColor(colors.yellow)
    term.setCursorPos(sx + 14, sy + 1) term.write("HELP")
    
    term.setTextColor(colors.white)
    term.setCursorPos(sx + 2, sy + 3)  term.write("Tab       - Switch panel")
    term.setCursorPos(sx + 2, sy + 4)  term.write("Space     - Select / Deselect")
    term.setCursorPos(sx + 2, sy + 5)  term.write("Enter     - Open folder / file")
    term.setCursorPos(sx + 2, sy + 6)  term.write("Backspace - Go back (up)")
    term.setCursorPos(sx + 2, sy + 7)  term.write("C         - Copy selected")
    term.setCursorPos(sx + 2, sy + 8)  term.write("M         - Move selected")
    term.setCursorPos(sx + 2, sy + 9)  term.write("H         - Close help")
    term.setCursorPos(sx + 2, sy + 10) term.write("Q         - Exit program")
end

-- Отрисовка интерфейса
local function draw()
    term.clear()
    local mid = math.floor(w / 2)
    
    term.setBackgroundColor(colors.gray)
    term.setCursorPos(1, 1) term.clearLine()
    term.setCursorPos(2, 1) term.write("/" .. leftDir)
    term.setCursorPos(mid + 2, 1) term.write("/" .. rightDir)
    term.setBackgroundColor(colors.black)
    
    for y = 2, h - 2 do term.setCursorPos(mid, y) term.write("|") end
    
    drawPanelList(leftFiles, leftDir, 2, mid, (activePanel == "left"), leftSel, leftSelected)
    drawPanelList(rightFiles, rightDir, mid + 2, mid, (activePanel == "right"), rightSel, rightSelected)
    
    -- Динамический статус-бар
    term.setBackgroundColor(colors.gray)
    term.setCursorPos(1, h) term.clearLine()
    
    local activeDir = (activePanel == "left") and leftDir or rightDir
    local activeFiles = (activePanel == "left") and leftFiles or rightFiles
    local activeSel = (activePanel == "left") and leftSel or rightSel
    local targetDir = (activePanel == "left") and rightDir or leftDir
    local selTable = (activePanel == "left") and leftSelected or rightSelected
    
    local selCount = getSelectedCount(selTable)
    
    if selCount > 0 then
        -- Если выделено несколько файлов
        local msg = " move: " .. selCount .. " item(s) to /" .. targetDir
        term.write(msg:sub(1, w))
    elseif #activeFiles > 0 then
        -- Если ничего не выделено, показываем путь для одного файла под курсором
        local currentFile = activeFiles[activeSel]
        local fromPath = "/" .. fs.combine(activeDir, currentFile)
        local toPath = "/" .. fs.combine(targetDir, currentFile)
        local msg = " move: " .. fromPath .. " to " .. toPath
        term.write(msg:sub(1, w))
    else
        term.write(" [Empty Panel] - Press H for Help")
    end
    
    term.setBackgroundColor(colors.black)
    if showHelp then drawHelpWindow() end
end

-- Главный цикл
while true do
    draw()
    local event, key = os.pullEvent("key")
    
    if showHelp then
        if key == keys.h then showHelp = false elseif key == keys.q then break end
    else
        if key == keys.q then break
        elseif key == keys.h then showHelp = true
        elseif key == keys.tab then activePanel = (activePanel == "left") and "right" or "left"
        elseif key == keys.up then
            if activePanel == "left" and leftSel > 1 then leftSel = leftSel - 1
            elseif activePanel == "right" and rightSel > 1 then rightSel = rightSel - 1 end
        elseif key == keys.down then
            if activePanel == "left" and leftSel < #leftFiles then leftSel = leftSel + 1
            elseif activePanel == "right" and rightSel < #rightFiles then rightSel = rightSel + 1 end
            
        elseif key == keys.space then
            -- Выделение по кнопке Пробел
            local activeFiles = (activePanel == "left") and leftFiles or rightFiles
            local activeSel = (activePanel == "left") and leftSel or rightSel
            local selTable = (activePanel == "left") and leftSelected or rightSelected
            
            if #activeFiles > 0 then
                local file = activeFiles[activeSel]
                if selTable[file] then selTable[file] = nil else selTable[file] = true end
            end
            
        elseif key == keys.enter then
            local currentDir = (activePanel == "left") and leftDir or rightDir
            local currentFiles = (activePanel == "left") and leftFiles or rightFiles
            local currentSel = (activePanel == "left") and leftSel or rightSel
            
            if #currentFiles > 0 then
                local selected = currentFiles[currentSel]
                local fullPath = fs.combine(currentDir, selected)
                
                if fs.isDir(fullPath) then
                    if activePanel == "left" then leftDir = fullPath leftSel = 1 clearSelection("left") refreshPanel("left")
                    else rightDir = fullPath rightSel = 1 clearSelection("right") refreshPanel("right") end
                else
                    term.clear() term.setCursorPos(1, 1)
                    shell.run("edit", fullPath)
                    refreshPanel("left") refreshPanel("right")
                end
            end
            
        elseif key == keys.backspace then
            if activePanel == "left" and leftDir ~= "" then
                leftDir = fs.getDir(leftDir) leftSel = 1 clearSelection("left") refreshPanel("left")
            elseif activePanel == "right" and rightDir ~= "" then
                rightDir = fs.getDir(rightDir) rightSel = 1 clearSelection("right") refreshPanel("right")
            end
            
        elseif key == keys.c or key == keys.m then
            -- Объединенная логика для Копирования (C) и Перемещения (M)
            local isMove = (key == keys.m)
            local srcDir = (activePanel == "left") and leftDir or rightDir
            local dstDir = (activePanel == "left") and rightDir or leftDir
            local srcFiles = (activePanel == "left") and leftFiles or rightFiles
            local srcSel = (activePanel == "left") and leftSel or rightSel
            local selTable = (activePanel == "left") and leftSelected or rightSelected
            
            -- Собираем список того, что нужно обработать
            local targets = {}
            if getSelectedCount(selTable) > 0 then
                for file in pairs(selTable) do table.insert(targets, file) end
            elseif #srcFiles > 0 then
                table.insert(targets, srcFiles[srcSel])
            end
            
            -- Выполняем операцию над всеми выбранными элементами
            for _, file in ipairs(targets) do
                local source = fs.combine(srcDir, file)
                local dest = fs.combine(dstDir, file)
                
                if not fs.exists(dest) then
                    if isMove then fs.move(source, dest) else fs.copy(source, dest) end
                end
            end
            
            -- Очищаем выделение и обновляем панели
            clearSelection(activePanel)
            refreshPanel("left")
            refreshPanel("right")
        end
    end
end

term.clear()
term.setCursorPos(1,1)
--

XXXXXXXXXX
local w, h = term.getSize()
-- Текущие пути и списки файлов
local leftDir, rightDir = "", ""
local leftFiles = fs.list(leftDir)
local rightFiles = fs.list(rightDir)
local activePanel = "left"
local leftSel, rightSel = 1, 1local showHelp = false
-- Групповое выделение
local leftSelected, rightSelected = {}, {}
local commandHistory = "" -- История командной строки
local function clearSelection(panel)
    if panel == "left" then leftSelected = {} else rightSelected = {} endend
local function getSelectedCount(selectedTable)
    local count = 0
    for _ in pairs(selectedTable) do count = count + 1 end
    return countend
local function refreshPanel(panel)
    if panel == "left" then
        leftFiles = fs.list(leftDir)
        if leftSel > #leftFiles then leftSel = math.max(1, #leftFiles) end
    else
        rightFiles = fs.list(rightDir)
        if rightSel > #rightFiles then rightSel = math.max(1, #rightFiles) end
    endend
-- Всплывающее окно для ввода текста (Имя файла/папки)
local function promptInput(title)
    local winW, winH = 30, 5
    local sx = math.floor((w - winW) / 2)
    local sy = math.floor((h - winH) / 2)
    
    term.setBackgroundColor(colors.gray)
    for y = sy, sy + winH - 1 do
        term.setCursorPos(sx, y)
        term.write(string.rep(" ", winW))
    end
    
    term.setTextColor(colors.yellow)
    term.setCursorPos(sx + 2, sy + 1)
    term.write(title)
    
    term.setBackgroundColor(colors.black)
    term.setTextColor(colors.white)
    term.setCursorPos(sx + 2, sy + 3)
    term.write(string.rep(" ", winW - 4))
    term.setCursorPos(sx + 2, sy + 3)
    
    local input = read()
    return (input ~= "") and input or nilend
-- Всплывающее окно прогресса операции
local function showProgressWindow(operation, currentFile, fromPath, toPath)
    local winW, winH = 36, 7
    local sx = math.floor((w - winW) / 2)
    local sy = math.floor((h - winH) / 2)
    
    term.setBackgroundColor(colors.gray)
    for y = sy, sy + winH - 1 do
        term.setCursorPos(sx, y)
        term.write(string.rep(" ", winW))
    end
    
    term.setTextColor(colors.yellow)
    term.setCursorPos(sx + 2, sy + 1)
    term.write("OPERATION: " .. operation:upper())
    
    term.setTextColor(colors.white)
    term.setCursorPos(sx + 2, sy + 3)
    term.write("Item: " .. currentFile:sub(1, winW - 10))
    
    if fromPath then
        term.setCursorPos(sx + 2, sy + 4)
        term.write("From: /" .. fromPath:sub(1, winW - 10))
    end
    if toPath then
        term.setCursorPos(sx + 2, sy + 5)
        term.write("To:   /" .. toPath:sub(1, winW - 10))
    end
    
    sleep(0.4) -- Небольшая задержка для визуализации прогрессаend
-- Отрисовка списка файлов
local function drawPanelList(files, currentDir, startX, mid, isActive, currentSel, selectedTable)
    for i, file in ipairs(files) do
        if i > h - 4 then break end -- Оставляем место под командную строку
        term.setCursorPos(startX, i + 1)
        
        local fullPath = fs.combine(currentDir, file)
        
        if isActive and i == currentSel then
            term.setBackgroundColor(colors.blue)
        elseif selectedTable[file] then
            term.setBackgroundColor(colors.green)
        else
            term.setBackgroundColor(colors.black)
        end
        
        if fs.isDir(fullPath) then
            term.setTextColor(colors.yellow)
        else
            term.setTextColor(colors.white)
        end
        
        term.write(file:sub(1, mid - 3) .. string.rep(" ", (mid - 3) - #file))
    end
    term.setTextColor(colors.white)end
-- Окно справки
local function drawHelpWindow()
    local hw, hh = 36, 12
    local sx = math.floor((w - hw) / 2)
    local sy = math.floor((h - hh) / 2)
    
    term.setBackgroundColor(colors.gray)
    for y = sy, sy + hh do term.setCursorPos(sx, y) term.write(string.rep(" ", hw)) end
    
    term.setTextColor(colors.yellow)
    term.setCursorPos(sx + 15, sy + 1) term.write("HELP")
    
    term.setTextColor(colors.white)
    term.setCursorPos(sx + 2, sy + 3)  term.write("Tab       - Switch panel")
    term.setCursorPos(sx + 2, sy + 4)  term.write("Space     - Select multiple")
    term.setCursorPos(sx + 2, sy + 5)  term.write("Enter     - Open folder/file")
    term.setCursorPos(sx + 2, sy + 6)  term.write("C / M     - Copy / Move selected")
    term.setCursorPos(sx + 2, sy + 7)  term.write("Delete    - Delete selected")
    term.setCursorPos(sx + 2, sy + 8)  term.write("F1 / F2   - Create File / Folder")
    term.setCursorPos(sx + 2, sy + 9)  term.write("H / Q     - Toggle Help / Exit")end
-- Главная отрисовка
local function draw()
    term.clear()
    local mid = math.floor(w / 2)
    
    -- Заголовки путей
    term.setBackgroundColor(colors.gray)
    term.setCursorPos(1, 1) term.clearLine()
    term.setCursorPos(2, 1) term.write("/" .. leftDir)
    term.setCursorPos(mid + 2, 1) term.write("/" .. rightDir)
    term.setBackgroundColor(colors.black)
    
    -- Разделитель
    for y = 2, h - 3 do term.setCursorPos(mid, y) term.write("|") end
    
    drawPanelList(leftFiles, leftDir, 2, mid, (activePanel == "left"), leftSel, leftSelected)
    drawPanelList(rightFiles, rightDir, mid + 2, mid, (activePanel == "right"), rightSel, rightSelected)
    
    -- Новая Командная Строка (заменяет старый статус-бар)
    term.setBackgroundColor(colors.gray)
    term.setCursorPos(1, h - 1) term.clearLine()
    term.write(" F1:NewFile | F2:NewDir | Del:Delete | H:Help")
    
    term.setBackgroundColor(colors.black)
    term.setCursorPos(1, h) term.clearLine()
    term.write("$/" .. ((activePanel == "left") and leftDir or rightDir) .. "> ")
    
    if showHelp then drawHelpWindow() endend
-- Главный цикл
while true do
    draw()
    local event, key = os.pullEvent("key")
    
    if showHelp then
        if key == keys.h then showHelp = false elseif key == keys.q then break end
    else
        if key == keys.q then
            break
        elseif key == keys.h then
            showHelp = true
        elseif key == keys.tab then
            activePanel = (activePanel == "left") and "right" or "left"
        elseif key == keys.up then
            if activePanel == "left" and leftSel > 1 then leftSel = leftSel - 1
            elseif activePanel == "right" and rightSel > 1 then rightSel = rightSel - 1 end
        elseif key == keys.down then
            if activePanel == "left" and leftSel < #leftFiles then leftSel = leftSel + 1
            elseif activePanel == "right" and rightSel < #rightFiles then rightSel = rightSel + 1 end
            
        elseif key == keys.space then
            local activeFiles = (activePanel == "left") and leftFiles or rightFiles
            local activeSel = (activePanel == "left") and leftSel or rightSel
            local selTable = (activePanel == "left") and leftSelected or rightSelected
            if #activeFiles > 0 then
                local file = activeFiles[activeSel]
                if selTable[file] then selTable[file] = nil else selTable[file] = true end
            end
            
        elseif key == keys.enter then
            -- Переход в командную строку, если нажали Enter (но только если под курсором ничего нет или это запуск терминала)
            local currentDir = (activePanel == "left") and leftDir or rightDir
            local currentFiles = (activePanel == "left") and leftFiles or rightFiles
            local currentSel = (activePanel == "left") and leftSel or rightSel
            
            if #currentFiles > 0 then
                local selected = currentFiles[currentSel]
                local fullPath = fs.combine(currentDir, selected)
                
                if fs.isDir(fullPath) then
                    if activePanel == "left" then leftDir = fullPath leftSel = 1 clearSelection("left") refreshPanel("left")
                    else rightDir = fullPath rightSel = 1 clearSelection("right") refreshPanel("right") end
                else
                    term.clear() term.setCursorPos(1, 1)
                    shell.run("edit", fullPath)
                    refreshPanel("left") refreshPanel("right")
                end
            else
                -- Активация ручного ввода в терминал, если панель пустая
                term.setCursorPos(#("./" .. currentDir) + 5, h)
                local cmd = read()
                if cmd and cmd ~= "" then shell.run(cmd) end
                refreshPanel("left") refreshPanel("right")
            end
            
        elseif key == keys.backspace then
            if activePanel == "left" and leftDir ~= "" then
                leftDir = fs.getDir(leftDir) leftSel = 1 clearSelection("left") refreshPanel("left")
            elseif activePanel == "right" and rightDir ~= "" then
                rightDir = fs.getDir(rightDir) rightSel = 1 clearSelection("right") refreshPanel("right")
            end

        elseif key == keys.f1 then
            -- Создать файл
            local name = promptInput("Enter new file name:")
            if name then
                local currentDir = (activePanel == "left") and leftDir or rightDir
                local fullPath = fs.combine(currentDir, name)
                term.clear() term.setCursorPos(1, 1)
                shell.run("edit", fullPath)
                refreshPanel(activePanel)
            end

        elseif key == keys.f2 then
            -- Создать папку
            local name = promptInput("Enter new folder name:")
            if name then
                local currentDir = (activePanel == "left") and leftDir or rightDir
                fs.makeDir(fs.combine(currentDir, name))
                refreshPanel(activePanel)
            end

        elseif key == keys.delete then
            -- Удаление
            local srcDir = (activePanel == "left") and leftDir or rightDir
            local srcFiles = (activePanel == "left") and leftFiles or rightFiles
            local srcSel = (activePanel == "left") and leftSel or rightSel

			local selTable = (activePanel == "left") and leftSelected or rightSelected
			local targets = {}
			if getSelectedCount(selTable) > 0 then
				for file in pairs(selTable) do table.insert(targets, file) end
			elseif #srcFiles > 0 then
				table.insert(targets, srcFiles[srcSel])
			end
			
			for _, file do
				local fullPath = fs.combine(srcDir, file)
				showProgressWindow("delete", file, fullPath, nil)
				fs.delete(fullPath)
			end
			clearSelection(activePanel)
			refreshPanel("left") refreshPanel("right")
			elseif key == keys.c or key == keys.m then
			
			-- Копирование и Перемещение с красивым Окном Прогресса
			local isMove = (key == keys.m)
			local opName = isMove and "move" or "copy"
			local srcDir = (activePanel == "left") and leftDir or rightDir
			local dstDir = (activePanel == "left") and rightDir or leftDir
			local srcFiles = (activePanel == "left") and leftFiles or rightFiles
			local srcSel = (activePanel == "left") and leftSel or rightSel
			local selTable = (activePanel == "left") and leftSelected or rightSelected
			local targets = {}
			if getSelectedCount(selTable) > 0 then
				for file in pairs(selTable) do table.insert(targets, file) end
			elseif #srcFiles > 0 then
				table.insert(targets, srcFiles[srcSel])
			end
			for _, file in ipairs(targets) do
				local source = fs.combine(srcDir, file)
				local dest = fs.combine(dstDir, file)
				if not fs.exists(dest) then
				-- Рисуем окно прогресса
				showProgressWindow(opName, file, source, dest)
				if isMove then fs.move(source, dest) else fs.copy(source, dest) end
			end
		end
		clearSelection(activePanel)
		refreshPanel("left") refreshPanel("right")
		end
	end
end
term.clear()
term.setCursorPos(1,1)

--

local w, h = term.getSize()

-- Store current paths and file lists for both panels
local leftDir, rightDir = "", ""
local leftFiles = fs.list(leftDir)
local rightFiles = fs.list(rightDir)

local activePanel = "left"
local leftSel, rightSel = 1, 1
local showHelp = false

-- Group selection tables
local leftSelected, rightSelected = {}, {}

local function clearSelection(panel)
    if panel == "left" then leftSelected = {} else rightSelected = {} end
end

local function getSelectedCount(selectedTable)
    local count = 0
    for _ in pairs(selectedTable) do count = count + 1 end
    return count
end

local function refreshPanel(panel)
    if panel == "left" then
        leftFiles = fs.list(leftDir)
        if leftSel > #leftFiles then leftSel = math.max(1, #leftFiles) end
    else
        rightFiles = fs.list(rightDir)
        if rightSel > #rightFiles then rightSel = math.max(1, #rightFiles) end
    end
end

-- Popup prompt window for text input (File/Folder name)
local function promptInput(title)
    local winW, winH = 30, 5
    local sx = math.floor((w - winW) / 2)
    local sy = math.floor((h - winH) / 2)
    
    term.setBackgroundColor(colors.gray)
    for y = sy, sy + winH - 1 do
        term.setCursorPos(sx, y)
        term.write(string.rep(" ", winW))
    end
    
    term.setTextColor(colors.yellow)
    term.setCursorPos(sx + 2, sy + 1)
    term.write(title)
    
    term.setBackgroundColor(colors.black)
    term.setTextColor(colors.white)
    term.setCursorPos(sx + 2, sy + 3)
    term.write(string.rep(" ", winW - 4))
    term.setCursorPos(sx + 2, sy + 3)
    
    local input = read()
    return (input ~= "") and input or nil
end

-- Operation progress window overlay
local function showProgressWindow(operation, currentFile, fromPath, toPath)
    local winW, winH = 36, 7
    local sx = math.floor((w - winW) / 2)
    local sy = math.floor((h - winH) / 2)
    
    term.setBackgroundColor(colors.gray)
    for y = sy, sy + winH - 1 do
        term.setCursorPos(sx, y)
        term.write(string.rep(" ", winW))
    end
    
    term.setTextColor(colors.yellow)
    term.setCursorPos(sx + 2, sy + 1)
    term.write("OPERATION: " .. operation:upper())
    
    term.setTextColor(colors.white)
    term.setCursorPos(sx + 2, sy + 3)
    term.write("Item: " .. currentFile:sub(1, winW - 10))
    
    if fromPath then
        term.setCursorPos(sx + 2, sy + 4)
        term.write("From: /" .. fromPath:sub(1, winW - 10))
    end
    if toPath then
        term.setCursorPos(sx + 2, sy + 5)
        term.write("To:   /" .. toPath:sub(1, winW - 10))
    end
    
    sleep(0.4) -- Short delay to visualize operation progress
end

-- Helper to draw file list inside a single panel
local function drawPanelList(files, currentDir, startX, mid, isActive, currentSel, selectedTable)
    for i, file in ipairs(files) do
        if i > h - 4 then break end -- Leave space for the shell path display
        term.setCursorPos(startX, i + 1)
        
        local fullPath = fs.combine(currentDir, file)
        
        if isActive and i == currentSel then
            term.setBackgroundColor(colors.blue)
        elseif selectedTable[file] then
            term.setBackgroundColor(colors.green)
        else
            term.setBackgroundColor(colors.black)
        end
        
        if fs.isDir(fullPath) then
            term.setTextColor(colors.yellow)
        else
            term.setTextColor(colors.white)
        end
        
        term.write(file:sub(1, mid - 3) .. string.rep(" ", (mid - 3) - #file))
    end
    term.setTextColor(colors.white)
end

-- Help window overlay
local function drawHelpWindow()
    local hw, hh = 36, 12
    local sx = math.floor((w - hw) / 2)
    local sy = math.floor((h - hh) / 2)
    
    term.setBackgroundColor(colors.gray)
    for y = sy, sy + hh do term.setCursorPos(sx, y) term.write(string.rep(" ", hw)) end
    
    term.setTextColor(colors.yellow)
    term.setCursorPos(sx + 15, sy + 1) term.write("HELP")
    
    term.setTextColor(colors.white)
    term.setCursorPos(sx + 2, sy + 3)  term.write("Tab   - Switch panel")
    term.setCursorPos(sx + 2, sy + 4)  term.write("Space - Select multiple")
    term.setCursorPos(sx + 2, sy + 5)  term.write("Enter - Open folder/file")
    term.setCursorPos(sx + 2, sy + 6)  term.write("C / M - Copy / Move selected")
    --term.setCursorPos(sx + 2, sy + 7)  term.write("Delete    - Delete selected")
	term.setCursorPos(sx + 2, sy + 7)  term.write("I     - Delete selected")
    --term.setCursorPos(sx + 2, sy + 8)  term.write("F1 / F2   - Create File / Folder")
	term.setCursorPos(sx + 2, sy + 8)  term.write("T / Y - Create File / Folder")
    term.setCursorPos(sx + 2, sy + 9)  term.write("H / Q - Toggle Help / Exit")
	term.setBackgroundColor(colors.black)
end

-- Main interface rendering loop
local function draw()
    term.clear()
	term.setBackgroundColor(colors.black)
    local mid = math.floor(w / 2)
    
    -- Directory path headers
    term.setBackgroundColor(colors.gray)
    term.setCursorPos(1, 1) term.clearLine()
    term.setCursorPos(2, 1) term.write("/" .. leftDir)
    term.setCursorPos(mid + 2, 1) term.write("/" .. rightDir)
    term.setBackgroundColor(colors.black)
    
    -- Panel vertical separator line
    --for y = 2, h - 3 do term.setCursorPos(mid, y) term.write("|") end
	for y = 2, h - 1 do term.setCursorPos(mid, y) term.write("|") end
    
    drawPanelList(leftFiles, leftDir, 2, mid, (activePanel == "left"), leftSel, leftSelected)
    drawPanelList(rightFiles, rightDir, mid + 2, mid, (activePanel == "right"), rightSel, rightSelected)
    
    -- Command bar overlay placeholder
    -- term.setBackgroundColor(colors.gray)
    -- term.setCursorPos(1, h - 1) term.clearLine()
    -- term.write(" F1:NewFile | F2:NewDir | Del:Delete | H:Help")
    
    -- Command-line prompt mimicking direct execution path
    term.setBackgroundColor(colors.black)
    term.setCursorPos(1, h) term.clearLine()
    term.write("$/" .. ((activePanel == "left") and leftDir or rightDir) .. "> ")
    
    if showHelp then drawHelpWindow() end
end

-- Core listener loop
while true do
    draw()
    local event, key = os.pullEvent("key")
    
    if showHelp then
        if key == keys.h then showHelp = false elseif key == keys.q then break end
    else
        if key == keys.q then
            break
        elseif key == keys.h then
            showHelp = true
        elseif key == keys.tab then
            activePanel = (activePanel == "left") and "right" or "left"
        elseif key == keys.up then
            if activePanel == "left" and leftSel > 1 then leftSel = leftSel - 1
            elseif activePanel == "right" and rightSel > 1 then rightSel = rightSel - 1 end
        elseif key == keys.down then
            if activePanel == "left" and leftSel < #leftFiles then leftSel = leftSel + 1
            elseif activePanel == "right" and rightSel < #rightFiles then rightSel = rightSel + 1 end
            
        elseif key == keys.space then
            local activeFiles = (activePanel == "left") and leftFiles or rightFiles
            local activeSel = (activePanel == "left") and leftSel or rightSel
            local selTable = (activePanel == "left") and leftSelected or rightSelected
            if #activeFiles > 0 then
                local file = activeFiles[activeSel]
                if selTable[file] then selTable[file] = nil else selTable[file] = true end
            end
            
        elseif key == keys.enter then
            local currentDir = (activePanel == "left") and leftDir or rightDir
            local currentFiles = (activePanel == "left") and leftFiles or rightFiles
            local currentSel = (activePanel == "left") and leftSel or rightSel
            
            if #currentFiles > 0 then
                local selected = currentFiles[currentSel]
                local fullPath = fs.combine(currentDir, selected)
                
                if fs.isDir(fullPath) then
                    if activePanel == "left" then leftDir = fullPath leftSel = 1 clearSelection("left") refreshPanel("left")
                    else rightDir = fullPath rightSel = 1 clearSelection("right") refreshPanel("right") end
                else
                    term.clear() term.setCursorPos(1, 1)
                    shell.run("edit", fullPath)
                    refreshPanel("left") refreshPanel("right")
                end
            else
                term.setCursorPos(#("./" .. currentDir) + 5, h)
                local cmd = read()
                if cmd and cmd ~= "" then shell.run(cmd) end
                refreshPanel("left") refreshPanel("right")
            end
            
        elseif key == keys.backspace then
            if activePanel == "left" and leftDir ~= "" then
                leftDir = fs.getDir(leftDir) leftSel = 1 clearSelection("left") refreshPanel("left")
            elseif activePanel == "right" and rightDir ~= "" then
                rightDir = fs.getDir(rightDir) rightSel = 1 clearSelection("right") refreshPanel("right")
            end

        --elseif key == keys.f1 then
		elseif key == keys.t then
            local name = promptInput("Enter new file name:")
            if name then
                local currentDir = (activePanel == "left") and leftDir or rightDir
                local fullPath = fs.combine(currentDir, name)
                term.clear() term.setCursorPos(1, 1)
                shell.run("edit", fullPath)
                refreshPanel(activePanel)
            end

        --elseif key == keys.f2 then
		elseif key == keys.y then
            local name = promptInput("Enter new folder name:")
            if name then
                local currentDir = (activePanel == "left") and leftDir or rightDir
                fs.makeDir(fs.combine(currentDir, name))
                refreshPanel(activePanel)
            end

        --elseif key == keys.delete then
		elseif key == keys.i then
            local srcDir = (activePanel == "left") and leftDir or rightDir
            local srcFiles = (activePanel == "left") and leftFiles or rightFiles
            local srcSel = (activePanel == "left") and leftSel or rightSel
            local selTable = (activePanel == "left") and leftSelected or rightSelected
            
            local targets = {}
            if getSelectedCount(selTable) > 0 then
				--
				for file in pairs(selTable) do table.insert(targets, file) end
			elseif #srcFiles > 0 then
				table.insert(targets, srcFiles[srcSel])
			end
			
			for _, file in ipairs(targets) do
				local fullPath = fs.combine(srcDir, file)
				showProgressWindow("delete", file, fullPath, nil)
				fs.delete(fullPath)
			end
			clearSelection(activePanel)
			refreshPanel("left") refreshPanel("right")
			elseif key == keys.c or key == keys.m then
			local isMove = (key == keys.m)
			local opName = isMove and "move" or "copy"
			local srcDir = (activePanel == "left") and leftDir or rightDir
			local dstDir = (activePanel == "left") and rightDir or leftDir
			local srcFiles = (activePanel == "left") and leftFiles or rightFiles
			local srcSel = (activePanel == "left") and leftSel or rightSel
			local selTable = (activePanel == "left") and leftSelected or rightSelected
			local targets = {}
			if getSelectedCount(selTable) > 0 then
				for file in pairs(selTable) do table.insert(targets, file) end
			elseif #srcFiles > 0 then
				table.insert(targets, srcFiles[srcSel])
			end
			for _, file in ipairs(targets) do
				local source = fs.combine(srcDir, file)
				local dest = fs.combine(dstDir, file)
				if not fs.exists(dest) then
					showProgressWindow(opName, file, source, dest)
				if isMove then fs.move(source, dest) else fs.copy(source, dest) end
			end
		end
		clearSelection(activePanel)
		refreshPanel("left") refreshPanel("right")
		end
	end
end
term.clear()
term.setCursorPos(1,1)

]]

local w, h = term.getSize()

-- Store current paths and file lists for both panels
local leftDir, rightDir = "", ""
local leftFiles = fs.list(leftDir)
local rightFiles = fs.list(rightDir)

local activePanel = "left"
local leftSel, rightSel = 1, 1
local showHelp = false

-- Group selection tables
local leftSelected, rightSelected = {}, {}

local function clearSelection(panel)
    if panel == "left" then leftSelected = {} else rightSelected = {} end
end

local function getSelectedCount(selectedTable)
    local count = 0
    for _ in pairs(selectedTable) do count = count + 1 end
    return count
end

local function refreshPanel(panel)
    if panel == "left" then
        leftFiles = fs.list(leftDir)
        if leftSel > #leftFiles then leftSel = math.max(1, #leftFiles) end
    else
        rightFiles = fs.list(rightDir)
        if rightSel > #rightFiles then rightSel = math.max(1, #rightFiles) end
    end
end

-- Popup prompt window for text input (File/Folder name)
local function promptInput(title)
    local winW, winH = 30, 5
    local sx = math.floor((w - winW) / 2)
    local sy = math.floor((h - winH) / 2)
    
    term.setBackgroundColor(colors.gray)
    for y = sy, sy + winH - 1 do
        term.setCursorPos(sx, y)
        term.write(string.rep(" ", winW))
    end
    
    term.setTextColor(colors.yellow)
    term.setCursorPos(sx + 2, sy + 1)
    term.write(title)
    
    term.setBackgroundColor(colors.black)
    term.setTextColor(colors.white)
    term.setCursorPos(sx + 2, sy + 3)
    term.write(string.rep(" ", winW - 4))
    term.setCursorPos(sx + 2, sy + 3)
    
    local input = read()
    return (input ~= "") and input or nil
end

-- Operation progress window overlay
local function showProgressWindow(operation, currentFile, fromPath, toPath)
    local winW, winH = 36, 7
    local sx = math.floor((w - winW) / 2)
    local sy = math.floor((h - winH) / 2)
    
    term.setBackgroundColor(colors.gray)
    for y = sy, sy + winH - 1 do
        term.setCursorPos(sx, y)
        term.write(string.rep(" ", winW))
    end
    
    term.setTextColor(colors.yellow)
    term.setCursorPos(sx + 2, sy + 1)
    term.write("OPERATION: " .. operation:upper())
    
    term.setTextColor(colors.white)
    term.setCursorPos(sx + 2, sy + 3)
    term.write("Item: " .. currentFile:sub(1, winW - 10))
    
    if fromPath then
        term.setCursorPos(sx + 2, sy + 4)
        term.write("From: /" .. fromPath:sub(1, winW - 10))
    end
    if toPath then
        term.setCursorPos(sx + 2, sy + 5)
        term.write("To:   /" .. toPath:sub(1, winW - 10))
    end
    
    sleep(0.4) -- Short delay to visualize operation progress
end

-- Helper to draw file list inside a single panel
local function drawPanelList(files, currentDir, startX, mid, isActive, currentSel, selectedTable)
    for i, file in ipairs(files) do
        if i > h - 4 then break end -- Leave space for the shell path display
        term.setCursorPos(startX, i + 1)
        
        local fullPath = fs.combine(currentDir, file)
        
        if isActive and i == currentSel then
            term.setBackgroundColor(colors.blue)
        elseif selectedTable[file] then
            term.setBackgroundColor(colors.green)
        else
            term.setBackgroundColor(colors.black)
        end
        
        if fs.isDir(fullPath) then
            term.setTextColor(colors.yellow)
        else
            term.setTextColor(colors.white)
        end
        
        term.write(file:sub(1, mid - 3) .. string.rep(" ", (mid - 3) - #file))
    end
    term.setTextColor(colors.white)
end

-- Help window overlay
local function drawHelpWindow()
    local hw, hh = 36, 12
    local sx = math.floor((w - hw) / 2)
    local sy = math.floor((h - hh) / 2)
    
    term.setBackgroundColor(colors.gray)
    for y = sy, sy + hh do term.setCursorPos(sx, y) term.write(string.rep(" ", hw)) end
    
    term.setTextColor(colors.yellow)
    term.setCursorPos(sx + 15, sy + 1) term.write("HELP")
    
    term.setTextColor(colors.white)
    term.setCursorPos(sx + 2, sy + 3)  term.write("Tab   - Switch panel")
    term.setCursorPos(sx + 2, sy + 4)  term.write("Space - Select multiple")
    term.setCursorPos(sx + 2, sy + 5)  term.write("Enter - Open folder/file")
    term.setCursorPos(sx + 2, sy + 6)  term.write("C / M - Copy / Move selected")
    --term.setCursorPos(sx + 2, sy + 7)  term.write("Delete    - Delete selected")
	term.setCursorPos(sx + 2, sy + 7)  term.write("I     - Delete selected")
    --term.setCursorPos(sx + 2, sy + 8)  term.write("F1 / F2   - Create File / Folder")
	term.setCursorPos(sx + 2, sy + 8)  term.write("T / Y - Create File / Folder")
    term.setCursorPos(sx + 2, sy + 9)  term.write("H / Q - Toggle Help / Exit")
	term.setBackgroundColor(colors.black)
end

-- Main interface rendering loop
local function draw()
    term.clear()
	term.setBackgroundColor(colors.black)
    local mid = math.floor(w / 2)
    
    -- Directory path headers
    term.setBackgroundColor(colors.gray)
    term.setCursorPos(1, 1) term.clearLine()
    term.setCursorPos(2, 1) term.write("/" .. leftDir)
    term.setCursorPos(mid + 2, 1) term.write("/" .. rightDir)
    term.setBackgroundColor(colors.black)
    
    -- Panel vertical separator line
    --for y = 2, h - 3 do term.setCursorPos(mid, y) term.write("|") end
	for y = 2, h - 1 do term.setCursorPos(mid, y) term.write("|") end
    
    drawPanelList(leftFiles, leftDir, 2, mid, (activePanel == "left"), leftSel, leftSelected)
    drawPanelList(rightFiles, rightDir, mid + 2, mid, (activePanel == "right"), rightSel, rightSelected)
    
    -- Command bar overlay placeholder
    -- term.setBackgroundColor(colors.gray)
    -- term.setCursorPos(1, h - 1) term.clearLine()
    -- term.write(" F1:NewFile | F2:NewDir | Del:Delete | H:Help")
    
    -- Command-line prompt mimicking direct execution path
    term.setBackgroundColor(colors.black)
    term.setCursorPos(1, h) term.clearLine()
    term.write("$/" .. ((activePanel == "left") and leftDir or rightDir) .. "> ")
    
    if showHelp then drawHelpWindow() end
end

-- Core listener loop
while true do
    draw()
    local event, key = os.pullEvent("key")
    
    if showHelp then
        if key == keys.h then showHelp = false elseif key == keys.q then break end
    else
        if key == keys.q then
            break
        elseif key == keys.h then
            showHelp = true
        elseif key == keys.tab then
            activePanel = (activePanel == "left") and "right" or "left"
        elseif key == keys.up then
            if activePanel == "left" and leftSel > 1 then leftSel = leftSel - 1
            elseif activePanel == "right" and rightSel > 1 then rightSel = rightSel - 1 end
        elseif key == keys.down then
            if activePanel == "left" and leftSel < #leftFiles then leftSel = leftSel + 1
            elseif activePanel == "right" and rightSel < #rightFiles then rightSel = rightSel + 1 end
            
        elseif key == keys.space then
            local activeFiles = (activePanel == "left") and leftFiles or rightFiles
            local activeSel = (activePanel == "left") and leftSel or rightSel
            local selTable = (activePanel == "left") and leftSelected or rightSelected
            if #activeFiles > 0 then
                local file = activeFiles[activeSel]
                if selTable[file] then selTable[file] = nil else selTable[file] = true end
            end
            
        elseif key == keys.enter then
            local currentDir = (activePanel == "left") and leftDir or rightDir
            local currentFiles = (activePanel == "left") and leftFiles or rightFiles
            local currentSel = (activePanel == "left") and leftSel or rightSel
            
            if #currentFiles > 0 then
                local selected = currentFiles[currentSel]
                local fullPath = fs.combine(currentDir, selected)
                
                if fs.isDir(fullPath) then
                    if activePanel == "left" then leftDir = fullPath leftSel = 1 clearSelection("left") refreshPanel("left")
                    else rightDir = fullPath rightSel = 1 clearSelection("right") refreshPanel("right") end
                else
                    term.clear() term.setCursorPos(1, 1)
                    shell.run("edit", fullPath)
                    refreshPanel("left") refreshPanel("right")
                end
            else
                term.setCursorPos(#("./" .. currentDir) + 5, h)
                local cmd = read()
                if cmd and cmd ~= "" then shell.run(cmd) end
                refreshPanel("left") refreshPanel("right")
            end
            
        elseif key == keys.backspace then
            if activePanel == "left" and leftDir ~= "" then
                leftDir = fs.getDir(leftDir) leftSel = 1 clearSelection("left") refreshPanel("left")
            elseif activePanel == "right" and rightDir ~= "" then
                rightDir = fs.getDir(rightDir) rightSel = 1 clearSelection("right") refreshPanel("right")
            end

        --elseif key == keys.f1 then
		elseif key == keys.t then
            local name = promptInput("Enter new file name:")
            if name then
                local currentDir = (activePanel == "left") and leftDir or rightDir
                local fullPath = fs.combine(currentDir, name)
                term.clear() term.setCursorPos(1, 1)
                shell.run("edit", fullPath)
                refreshPanel(activePanel)
            end

        --elseif key == keys.f2 then
		elseif key == keys.y then
            local name = promptInput("Enter new folder name:")
            if name then
                local currentDir = (activePanel == "left") and leftDir or rightDir
                fs.makeDir(fs.combine(currentDir, name))
                refreshPanel(activePanel)
            end

        --elseif key == keys.delete then
		elseif key == keys.i then
            local srcDir = (activePanel == "left") and leftDir or rightDir
            local srcFiles = (activePanel == "left") and leftFiles or rightFiles
            local srcSel = (activePanel == "left") and leftSel or rightSel
            local selTable = (activePanel == "left") and leftSelected or rightSelected
            
            local targets = {}
            if getSelectedCount(selTable) > 0 then
				--
				for file in pairs(selTable) do table.insert(targets, file) end
			elseif #srcFiles > 0 then
				table.insert(targets, srcFiles[srcSel])
			end
			
			for _, file in ipairs(targets) do
				local fullPath = fs.combine(srcDir, file)
				showProgressWindow("delete", file, fullPath, nil)
				fs.delete(fullPath)
			end
			clearSelection(activePanel)
			refreshPanel("left") refreshPanel("right")
			elseif key == keys.c or key == keys.m then
			local isMove = (key == keys.m)
			local opName = isMove and "move" or "copy"
			local srcDir = (activePanel == "left") and leftDir or rightDir
			local dstDir = (activePanel == "left") and rightDir or leftDir
			local srcFiles = (activePanel == "left") and leftFiles or rightFiles
			local srcSel = (activePanel == "left") and leftSel or rightSel
			local selTable = (activePanel == "left") and leftSelected or rightSelected
			local targets = {}
			if getSelectedCount(selTable) > 0 then
				for file in pairs(selTable) do table.insert(targets, file) end
			elseif #srcFiles > 0 then
				table.insert(targets, srcFiles[srcSel])
			end
			for _, file in ipairs(targets) do
				local source = fs.combine(srcDir, file)
				local dest = fs.combine(dstDir, file)
				if not fs.exists(dest) then
					showProgressWindow(opName, file, source, dest)
				if isMove then fs.move(source, dest) else fs.copy(source, dest) end
			end
		end
		
		elseif key == keys.f then
			end
		
		elseif key == keys.c or key == keys.m then
		
		clearSelection(activePanel)
		refreshPanel("left") refreshPanel("right")
		end
	end
end
term.clear()
term.setCursorPos(1,1)