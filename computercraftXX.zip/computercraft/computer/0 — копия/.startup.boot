{
  preload = {},
  delay = 1.5,
  menu = {
    {
      prompt = "CraftOS 1.9",
    },
    {
      args = {
        "/sys/boot/opus.lua",
      },
      prompt = "Opus",
    },
    {
      args = {
        "/sys/boot/opus.lua",
        "/sys/apps/shell.lua",
      },
      prompt = "Opus Shell",
    },
    {
      args = {
        "/sys/boot/kiosk.lua",
      },
      prompt = "Opus Kiosk",
    },
    {
      args = {
        "/sys/boot/tlco.lua",
      },
      prompt = "Opus TLCO",
    },
  },
}