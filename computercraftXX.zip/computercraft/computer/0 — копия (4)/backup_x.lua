--[[
local args = { ... }
local path = args[1]
local path1 = args[2] or path
local name = args[2]

if not path then
    print("Usage: backup_x <path> <to path> <name>")
    return
end

-- Функция для URL-кодирования (необходима для отправки данных)
local function urlEncode(str)
    if str then
        str = str:gsub("\n", "\r\n")
        str = str:gsub("([^%w %-%_%.%~])", function(c)
            return string.format("%%%02X", string.byte(c))
        end)
        str = str:gsub(" ", "+")
    end
    return str
end

local archive = {}

-- Функция рекурсивного обхода всех папок и файлов
local function scanDirectory(dir)
    local list = fs.list(dir)
    for _, item in ipairs(list) do
        local path = fs.combine(dir, item)
        
        if fs.isDir(path) then
			scanDirectory(path) -- Если папка, заходим внутрь
		else
			-- Если файл, читаем его содержимое
			local f = fs.open(path, "r")
			if f then
				archive[path] = f.readAll()
				f.close()
				print("Packed: " .. path)
			end
		end
    end
end

local function runBackup(path, path1)
    print("Scanning and packing files...")
    scanDirectory(path)

    -- Сериализуем (превращаем таблицу в текст)
    local serializedData = textutils.serialize(archive)
	
	
	
	--local finalName = name or path:match("([^/]+)$")
    
    print("\n[SUCCESS] Archive create!")
	--local log = fs.open(path1 .. "/" .. finalName .. ".txt", "w")
	--print(finalName)
	--print(string.format("%s/%s.txt", path1, finalName))
	
	
	
	--local log = fs.open(string.format("%s/%s.txt", path1, finalName), "w")
	--log.write(serializedData)
	--log.close()
end

runBackup(path, path1)
]]

local args = { ... }
local path = args[1]
local path1 = args[2] or path
local name = args[3]

if not path then
    print("Usage: backup_x <path> <to path>")
    return
end

-- if not path1 then
    -- print("Usage: backup_x <path> <to path>")
    -- return
-- end

-- Функция для URL-кодирования (необходима для отправки данных)
local function urlEncode(str)
    if str then
        str = str:gsub("\n", "\r\n")
        str = str:gsub("([^%w %-%_%.%~])", function(c)
            return string.format("%%%02X", string.byte(c))
        end)
        str = str:gsub(" ", "+")
    end
    return str
end

local archive = {}

-- Функция рекурсивного обхода всех папок и файлов
local function scanDirectory(dir)
	if fs.isDir(dir) then
		local list = fs.list(dir)
		for _, item in ipairs(list) do
			local path = fs.combine(dir, item)
			
			if fs.isDir(path) then
				scanDirectory(path) -- Если папка, заходим внутрь
			else
				-- Если файл, читаем его содержимое
				local f = fs.open(path, "r")
				if f then
					archive[path] = f.readAll()
					f.close()
					print("Packed: " .. path)
				end
			end
		end
		return 1
	else
		print(string.format("Error: %s not a directory", dir))
		return 0
	end
end

local function runBackup(path, path1)
    print("Scanning and packing files...")
    local ok = scanDirectory(path)
	
	if ok == 0 then
		return
	end

    -- Сериализуем (превращаем таблицу в текст)
    local serializedData = textutils.serialize(archive)
    
    print("\n[SUCCESS] Archive create!")
	local finalName = name or path:match("([^/]+)$")
	print("Name: " .. finalName)
	--print("Path: " .. path1)
	local finalArchivePath = string.format("%s%s.txt", path1, finalName)
	print("Path: " .. finalArchivePath)
	
	local log = fs.open(finalArchivePath, "w")
	log.write(serializedData)
	log.close()
end

runBackup(path, path1)
