--[[
local side = "back"
local filename = "peripheral_log.txt"

local p = peripheral.wrap(side)
if not p then
    print("Peripheral not found on side: " .. side)
    return
end

-- Open file for writing
local file = fs.open(filename, "w")
if not file then
    print("Error: Could not create file " .. filename)
    return
end

-- Helper function to log both to screen and file
local function log(text)
    print(text)
    file.writeLine(text)
end

-- Deep inspection function
local function inspect(obj, prefix)
    prefix = prefix or ""
    local seen = {}
    
    for k, v in pairs(obj) do
        local fullName = prefix == "" and k or (prefix .. "." .. k)
        local vType = type(v)
        
        if vType == "function" then
            -- Try to call the function without arguments
            local success, res = pcall(v)
            if success then
                log(string.format("[Method] %s() -> %s", fullName, tostring(res)))
            else
                log(string.format("[Method] %s(requires arguments)", fullName))
            end
        elseif vType == "table" then
            log(string.format("[Table ] %s", fullName))
            -- Protect against infinite recursion
            if not seen[v] then
                seen[v] = true
                inspect(v, fullName)
            end
        else
            log(string.format("[Field ] %s = %s (%s)", fullName, tostring(v), vType))
        end
    end
end

-- Phase 1: Standard methods
log("--- Standard Peripheral Methods ---")
local methods = peripheral.getMethods(side)
if methods then
    for _, name in ipairs(methods) do
        local fn = p[name]
        if type(fn) == "function" then
            local ok, res = pcall(fn)
            if ok then
                log(string.format("  %s() -> %s", name, tostring(res)))
            else
                log(string.format("  %s() (requires arguments)", name))
            end
        end
    end
end

-- Phase 2: Full object scan
log("\n--- Full Object Scan ---")
inspect(p)

-- Close the file at the end
file.close()
log("\nDone! Results saved to " .. filename)
----
]]

local side = "back"
local filename = "peripheral_log.txt"

local p = peripheral.wrap(side)
if not p then
    print("Peripheral not found on side: " .. side)
    return
end

local file = fs.open(filename, "w")
if not file then
    print("Error: Could not create file " .. filename)
    return
end

local function log(text)
    print(text)
	if file then
		file.writeLine(text)
	end
end

-- Единая таблица для отслеживания посещенных узлов
local seen = {}

local function inspect(obj, prefix)
    prefix = prefix or ""
    
    -- Защита от зацикливания на самом верхнем уровне таблицы
    if seen[obj] then return end
    seen[obj] = true
    
    for k, v in pairs(obj) do
        local fullName = prefix == "" and k or (prefix .. "." .. k)
        local vType = type(v)
        
        if vType == "function" then
            local success, res = pcall(v)
            if success then
                log(string.format("[Method] %s() -> %s", fullName, tostring(res)))
            else
                log(string.format("[Method] %s(requires arguments)", fullName))
            end
        elseif vType == "table" then
            log(string.format("[Table ] %s", fullName))
            -- Рекурсивный вызов с передачей флага проверки
            if not seen[v] then
                inspect(v, fullName)
            end
        else
            log(string.format("[Field ] %s = %s (%s)", fullName, tostring(v), vType))
        end
    end
end

log("--- Standard Peripheral Methods ---")
local methods = peripheral.getMethods(side)
if methods then
    for _, name in ipairs(methods) do
        local fn = p[name]
        if type(fn) == "function" then
            local ok, res = pcall(fn)
            if ok then
                log(string.format("  %s() -> %s", name, tostring(res)))
            else
                log(string.format("  %s() (requires arguments)", name))
            end
        end
    end
end

log("\n--- Full Object Scan ---")
inspect(p)

-- Файл закроется строго один раз после завершения всех логов
--file.close()
log("\nDone! Results saved to " .. filename)
file.close()
