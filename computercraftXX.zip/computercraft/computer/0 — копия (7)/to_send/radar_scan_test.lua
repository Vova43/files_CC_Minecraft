local radarMon = peripheral.wrap("back")
local tracks = radarMon.getTracks()

if tracks and tracks[1] then
    for key, value in pairs(tracks[1]) do
        print(string.format("%s: %s", tostring(key), tostring(value)))
    end
else
    print("null.")
end
