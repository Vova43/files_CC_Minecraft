-- Ð£ÑÐ¸Ð»Ð¸ÑÐ° Ð´Ð»Ñ Ð°Ð²ÑÐ¾Ð¼Ð°ÑÐ¸ÑÐµÑÐºÐ¾Ð¹ Ð²ÑÐ³ÑÑÐ·ÐºÐ¸ Ð²ÑÐµÑ ÑÐ°Ð¹Ð»Ð¾Ð² Ð½Ð° Pastebin
local function uploadFile(path)
    -- ÐÑÐ¾Ð¿ÑÑÐºÐ°ÐµÐ¼ ÑÐ¸ÑÑÐµÐ¼Ð½ÑÐµ Ð¿Ð°Ð¿ÐºÐ¸ (rom) Ð¸ ÑÐ°Ð¼Ñ ÑÑÐ¸Ð»Ð¸ÑÑ
    if path == "rom" or path == "backup.lua" or path == "backup" then 
        return 
    end

    if fs.isDir(path) then
        -- ÐÑÐ»Ð¸ ÑÑÐ¾ Ð¿Ð°Ð¿ÐºÐ°, ÑÐºÐ°Ð½Ð¸ÑÑÐµÐ¼ ÐµÑ ÑÐ¾Ð´ÐµÑÐ¶Ð¸Ð¼Ð¾Ðµ
        local files = fs.list(path)
        for _, file in ipairs(files) do
            uploadFile(fs.combine(path, file))
        end
    else
        -- ÐÑÐ»Ð¸ ÑÑÐ¾ ÑÐ°Ð¹Ð», Ð·Ð°Ð³ÑÑÐ¶Ð°ÐµÐ¼ ÐµÐ³Ð¾ ÑÐµÑÐµÐ· Ð²ÑÑÑÐ¾ÐµÐ½Ð½Ð¾Ðµ API pastebin
        print("Uploading: " .. path)
        
        -- Ð§Ð¸ÑÐ°ÐµÐ¼ ÑÐ¾Ð´ÐµÑÐ¶Ð¸Ð¼Ð¾Ðµ ÑÐ°Ð¹Ð»Ð°
        local f = fs.open(path, "r")
        local content = f.readAll()
        f.close()

        -- Ð¤Ð¾ÑÐ¼Ð¸ÑÑÐµÐ¼ Ð¸Ð¼Ñ Ð´Ð»Ñ Pastebin
        local pasteName = "CC_Backup_" .. path

        -- ÐÑÐ¿ÑÐ°Ð²Ð»ÑÐµÐ¼ Ð·Ð°Ð¿ÑÐ¾Ñ Ðº API Pastebin ÑÐµÑÐµÐ· Ð²ÑÑÑÐ¾ÐµÐ½Ð½ÑÑ ÑÑÐ¸Ð»Ð¸ÑÑ
        local p = shell.run("pastebin", "put", path)
        -- Ð ÑÐ¾Ð¶Ð°Ð»ÐµÐ½Ð¸Ñ, Ð²ÑÑÑÐ¾ÐµÐ½Ð½ÑÐ¹ pastebin Ð¿ÑÐ¾ÑÑÐ¾ Ð¿Ð¸ÑÐµÑ ÐºÐ¾Ð´ Ð² ÐºÐ¾Ð½ÑÐ¾Ð»Ñ.
        -- Ð§ÑÐ¾Ð±Ñ ÑÐ´ÐµÐ»Ð°ÑÑ ÑÑÐ¾ ÐºÑÐ°ÑÐ¸Ð²Ð¾ Ð¸ ÑÐ¾ÑÑÐ°Ð½Ð¸ÑÑ ÐºÐ¾Ð´Ñ, Ð¸ÑÐ¿Ð¾Ð»ÑÐ·ÑÐµÐ¼ Ð¿ÑÑÐ¼Ð¾Ð¹ HTTP Ð·Ð°Ð¿ÑÐ¾Ñ:
    end
end

-- Ð£Ð»ÑÑÑÐµÐ½Ð½Ð°Ñ Ð²ÐµÑÑÐ¸Ñ Ñ ÑÐ¾ÑÑÐ°Ð½ÐµÐ½Ð¸ÐµÐ¼ ÑÑÑÐ»Ð¾Ðº Ð² ÑÐ°Ð¹Ð» log.txt
local function smartBackup()
    if not http then
        printError("Error: HTTP API is disabled on this server!")
        return
    end

    local files = fs.list("")
    local log = fs.open("backup_log.txt", "w")
    log.writeLine("=== BACKUP CODES ===")

    for _, file in ipairs(files) do
        if file ~= "rom" and file ~= "backup.lua" and file ~= "backup_log.txt" then
            if not fs.isDir(file) then
                print("Uploading " .. file .. "...")
                
                -- Ð§Ð¸ÑÐ°ÐµÐ¼ ÑÐ°Ð¹Ð»
                local f = fs.open(file, "r")
                local text = f.readAll()
                f.close()

                -- ÐÑÐ¿ÑÐ°Ð²Ð»ÑÐµÐ¼ Ð½Ð° Pastebin Ð½Ð°Ð¿ÑÑÐ¼ÑÑ ÑÐµÑÐµÐ· HTTP POST
                local response = http.post(
                    "https://pastebin.com",
                    "api_option=paste&api_dev_key=0b20de043ec13dca60ec68dddf7f2e9e&api_paste_code=" .. 
                    text:urlEncode() .. "&api_paste_name=" .. file
                )

                if response then
                    local resText = response.readAll()
                    response.close()
                    if resText:find("https://pastebin.com") then
                        local code = resText:sub(21)
                        print("Success! Code: " .. code)
                        log.writeLine(file .. " -> " .. code)
                    else
                        print("Error uploading " .. file .. ": " .. resText)
                    end
                else
                    print("Failed to connect to Pastebin for " .. file)
                end
                sleep(0.5) -- ÐÐµÐ±Ð¾Ð»ÑÑÐ°Ñ Ð¿Ð°ÑÐ·Ð°, ÑÑÐ¾Ð±Ñ Pastebin Ð½Ðµ Ð·Ð°Ð±Ð»Ð¾ÐºÐ¸ÑÐ¾Ð²Ð°Ð» Ð·Ð° ÑÐ¿Ð°Ð¼
            end
        end
    end
    log.close()
    print("\nDone! All codes saved to 'backup_log.txt'")
end

smartBackup()
