local function findMonitor(whatToFind)
    local PeriList = peripheral.getNames()
        for i=1,#PeriList do
            if peripheral.getType(PeriList[i]) == whatToFind then
                return PeriList[i]
        end
    end
end

-- 1. Find monitor
local monitorName = findMonitor("monitor")
-- 2. If found monitor to do
if monitorName then
    local mon = peripheral.wrap(monitorName)
    -- 3. Print message
    mon.clear()
    mon.setTextColor(colors.green)
    mon.setCursorPos(1, 1)
    mon.write("Hello world 1 !")
else
    print("Can't found monitor")
end
