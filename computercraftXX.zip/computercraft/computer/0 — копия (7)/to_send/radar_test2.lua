local controller = peripheral.wrap("back")
local size = controller.size()

local foundAny = false
for slot = 1, size do
    local detail = controller.getItemDetail(slot)
    if detail then
        foundAny = true
        print(string.format("\n[slot %d] item: %s", slot, detail.name))
        print("count: " .. detail.count)
        
        print(textutils.serialize(detail))
    end
end

if not foundAny then
    print("...")
end
