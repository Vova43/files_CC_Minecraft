local radar = peripheral.find("create_radar:monitor")

if radar then
    for _, method in ipairs(peripheral.getMethods(peripheral.getName(radar))) do
        print(method)
    end
end

local periList = peripheral.getNames()
print("block")
for i = 1, #periList do
    print(string.format("%s -> %s", periList[i], peripheral.getType(periList[i])))
end
