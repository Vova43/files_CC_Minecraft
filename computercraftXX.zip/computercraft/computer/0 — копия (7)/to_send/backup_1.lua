-- Ð¤ÑÐ½ÐºÑÐ¸Ñ Ð´Ð»Ñ URL-ÐºÐ¾Ð´Ð¸ÑÐ¾Ð²Ð°Ð½Ð¸Ñ ÑÑÑÐ¾Ðº (Ð¸ÑÐ¿ÑÐ°Ð²Ð»ÐµÐ½Ð¸Ðµ Ð¾ÑÐ¸Ð±ÐºÐ¸)
local function urlEncode(str)
    if str then
        str = str:gsub("\n", "\r\n")
        str = str:gsub("([^%w %-%_%.%~])", function(c)
            return string.format("%%%02X", string.byte(c))
        end)
        str = str:gsub(" ", "+")
    end
    return str
end

local function smartBackup()
    if not http then
        printError("Error: HTTP API is disabled on this server!")
        return
    end

    local files = fs.list("")
    local log = fs.open("backup_log.txt", "w")
    log.writeLine("=== BACKUP CODES ===")

    for _, file in ipairs(files) do
        -- ÐÐ³Ð½Ð¾ÑÐ¸ÑÑÐµÐ¼ ÑÐ¸ÑÑÐµÐ¼Ñ, ÑÐ°Ð¼ ÑÐºÑÐ¸Ð¿Ñ Ð¸ ÑÐ°Ð¹Ð» Ð»Ð¾Ð³Ð¾Ð²
        if file ~= "rom" and file ~= "backup.lua" and file ~= "backup" and file ~= "backup_log.txt" then
            if not fs.isDir(file) then
                print("Uploading " .. file .. "...")
                
                -- Ð§Ð¸ÑÐ°ÐµÐ¼ ÑÐ°Ð¹Ð»
                local f = fs.open(file, "r")
                local text = f.readAll()
                f.close()

                -- ÐÐµÐ·Ð¾Ð¿Ð°ÑÐ½Ð¾Ðµ ÐºÐ¾Ð´Ð¸ÑÐ¾Ð²Ð°Ð½Ð¸Ðµ ÑÐµÐºÑÑÐ° Ð¸ Ð¸Ð¼ÐµÐ½Ð¸ ÑÐ°Ð¹Ð»Ð°
                local encodedText = urlEncode(text)
                local encodedName = urlEncode(file)

                -- ÐÑÐ¿ÑÐ°Ð²Ð»ÑÐµÐ¼ Ð½Ð° Pastebin Ð½Ð°Ð¿ÑÑÐ¼ÑÑ ÑÐµÑÐµÐ· HTTP POST
                local response = http.post(
                    "https://pastebin.com",
                    "api_option=paste&api_dev_key=0b20de043ec13dca60ec68dddf7f2e9e" ..
                    "&api_paste_code=" .. encodedText .. 
                    "&api_paste_name=" .. encodedName
                )

                if response then
                    local resText = response.readAll()
                    response.close()
                    if resText:find("https://pastebin.com") then
                        local code = resText:sub(22) -- ÐÐ·Ð²Ð»ÐµÐºÐ°ÐµÐ¼ ÑÐ¸ÑÑÑÐ¹ ÐºÐ¾Ð´ Ð¸Ð· ÑÑÑÐ»ÐºÐ¸
                        print("Success! Code: " .. code)
                        log.writeLine(file .. " -> " .. code)
                    else
                        print("Error uploading " .. file .. ": " .. resText)
                    end
                else
                    print("Failed to connect to Pastebin for " .. file)
                end
                sleep(0.5) -- ÐÐ°ÑÐ¸ÑÐ° Ð¾Ñ Ð±Ð»Ð¾ÐºÐ¸ÑÐ¾Ð²ÐºÐ¸ Ð·Ð° ÑÐ¿Ð°Ð¼ Ð·Ð°Ð¿ÑÐ¾ÑÐ°Ð¼Ð¸
            end
        end
    end
    log.close()
    print("\nDone! All codes saved to 'backup_log.txt'")
end

smartBackup()
