local side = "back"
local p = peripheral.wrap(side)

if not p then
    print("not found!")
    return
end

local methods = peripheral.getMethods(side)
for _, methodName in ipairs(methods) do
    local success, result = pcall(p[methodName])
    if success then
        if type(result) == "table" then
            print(string.format("[Func] %s() -> return table (size: %d)", methodName, #result))
        else
            print(string.format("[Func] %s() -> %s", methodName, tostring(result)))
        end
    else
        print(string.format("[Func] %s(...) ->  ", methodName))
    end
end
