local radarMon = peripheral.wrap("back")

if not radarMon then
    error("ERROR")
end

while true do
    term.clear()
    term.setCursorPos(1, 1)
    
    print("TEST")
    local tracks = radarMon.getTracks()
    
    if not tracks or #tracks == 0 then
        print("OK")
    else
        for i, track in ipairs(tracks) do
            --print(string.format("%d. ID: %s", i, tostring(track.id or "???")))
            if track.x and track.y and track.z then
                print(string.format("c: X:%.1f Y:%.1f Z:%.1f", track.x, track.y, track.z))
            end
        end
    end
    sleep(1)
end    
