local webhookUrl = "https://discord.com/api/webhooks/1532452356485288137/0kv4yuSL8lROFiK17brqccU9si57zTJIKGQkCwlO4pYdT4LVRZk4w9SNDfnVn5W2aTWv"

local targetSide = "back"

local function sendToDiscord(text)
    local body = textutils.serializeJSON({ content = text })
    local headers = { ["Content-Type"] = "application/json" }
    local success, err = http.post(webhookUrl, body, headers)
    if success then print("  Discord!") else print(": " .. tostring(err)) end 
end

print("back[" .. targetSide .. "]start") 

while true do
    os.pullEvent("redstone")
    if rs.getInput(targetSide) then
        print("back signal")
        sendToDiscord("enemy!")
        while rs.getInput(targetSide) do
            sleep(0.5)
        end
        print("stop")
    end
end   
         
             
             
             
