local radarMon = peripheral.wrap("back")
local tracks = radarMon.getTracks()

if tracks then
    for i = 1, #tracks do
        local target = tracks[i]
        if target.category == "PLAYER" then
        
        for key, value in pairs(target) do
            print(string.format("%s: %s", tostring(key), tostring(value)))
        end
        
        end
    end
else
    print("null.")
end
