local bridge = peripheral.find("redstone_link_bridge")

if bridge then
    bridge.sendLinkSignal("minecraft:cobblestone", "minecraft:redstone", 15)
    print("OK")
else
    print("ERROR")
end
