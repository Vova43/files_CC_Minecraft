local bridge = peripheral.find("redstone_link_bridge")
local mon = peripheral.find("monitor")

if bridge then
    --bridge.sendLinkSignal("minecraft:cobblestone", "minecraft:redstone", 0)
    print("OK")
    while true do
        local currentSignal = bridge.getLinkSignal("minecraft:cobblestone", "minecraft:redstone")
        term.clear()
        term.setCursorPos(1,1)
        print(string.format("signal: %d", currentSignal))
        if mon then
            mon.clear()
            mon.setCursorPos(1, 1)
            mon.write(string.format("Signal: %d ", currentSignal))
        end
    end
    
else
    print("ERROR")
end
