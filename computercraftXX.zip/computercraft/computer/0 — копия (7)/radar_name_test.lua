local radar_side = "back"
local detector_side = "top"

local radar = peripheral.wrap(radar_side)
local detector = peripheral.wrap(detector_side)

if not radar or not detector then
    print("Check peripheral connections!")
    return
end

-- Функция прямого перевода UUID -> Ник
local function getNicknameByUUID(target_uuid)
    local players = detector.getOnlinePlayers()
    if not players then return "Unknown" end
    
    -- Перебираем игроков онлайн и точечно сверяем UUID
    for _, name in ipairs(players) do
        local data = detector.getPlayer(name)
        if data and data.id == target_uuid then -- в некоторых версиях AP поле называется 'id', в некоторых 'uuid'
            return name
        elseif data and data.uuid == target_uuid then
            return name
        end
    end
    return "Offline/Unknown"
end

-- Пример работы с радаром
local tracks = radar.getTracks()
if tracks then
    for _, entity in ipairs(tracks) do
        if entity.category == "PLAYER" then
            -- Прямая конвертация «на лету»
            local name = getNicknameByUUID(entity.id)
            
            print(string.format("Player detected: %s (UUID: %s)", name, entity.id))
        end
    end
end
