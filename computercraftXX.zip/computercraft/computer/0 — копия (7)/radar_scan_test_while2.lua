local radarMon = peripheral.wrap("back")

if not radarMon then
    error("xError")
end

while true do
    term.clear()
    term.setCursorPos(1, 1)
    
    local tracks = radarMon.getTracks()
    local playersFound = 0
	
	local selected = radarMon.getSelectedTrack()
	if selected then
		for k, v in pairs(selected) do
			print(k .. ": " .. tostring(v))
		end
	end
    
    if tracks then
        for i = 1, #tracks do
            local target = tracks[i]
            
            if target.category == "PLAYER" then
                playersFound = playersFound + 1
                
                local playerName = target.name or "null"
                print(string.format(" %s", playerName))
                
                local pos = target.position or {}
                local x = pos.x or 0
                local y = pos.y or 0
                local z = pos.z or 0
                
                local vel = target.velocity or {}
                local vx = vel.x or 0
                local vy = vel.y or 0
                local vz = vel.z or 0
                
                print(string.format("%d. player!", playersFound))
                print(string.format(" C: X:%.1f Y:%.1f Z:%.1f", x, y, z))
                
                local speed = math.sqrt(vx^2 + vy^2 + vz^2)
                if speed > 0.1 then
                    print(string.format(" Vspeed: %.2f m/s", speed * 20))
                end
                
            end
        end
    end
    
    if playersFound == 0 then
        print("null...")
    end
    
    sleep(0.5)
end
