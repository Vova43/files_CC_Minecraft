local side = "back"
local filename = "peripheral_log1.txt"

local p = peripheral.wrap(side)
if not p then
    print("Peripheral not found on side: " .. side)
    return
end

local file = fs.open(filename, "w")
if not file then
    print("Error: Could not create file " .. filename)
    return
end

local function log(text)
    print(text)
    file.writeLine(text)
end

-- Функция для красивого превращения простых таблиц в текст
local function serializeTable(tbl)
    local items = {}
    for k, v in pairs(tbl) do
        local keyStr = type(k) == "number" and string.format("[%d]", k) or string.format('["%s"]', tostring(k))
        local valStr
        
        if type(v) == "string" then
            valStr = string.format('"%s"', v)
        elseif type(v) == "table" then
            valStr = "{...}" -- Для слишком глубоких вложенностей
        else
            valStr = tostring(v)
        end
        
        table.insert(items, string.format("%s = %s", keyStr, valStr))
    end
    return "{ " .. table.concat(items, ", ") .. " }"
end

-- Вспомогательная функция форматирования возвращаемых данных
local function formatResult(res)
    if type(res) == "table" then
        return serializeTable(res)
    else
        return tostring(res)
    end
end

local seen = {}

local function inspect(obj, prefix)
    prefix = prefix or ""
    
    if seen[obj] then return end
    seen[obj] = true
    
    for k, v in pairs(obj) do
        local fullName = prefix == "" and k or (prefix .. "." .. k)
        local vType = type(v)
        
        if vType == "function" then
            local success, res = pcall(v)
            if success then
                log(string.format("[Method] %s() -> %s", fullName, formatResult(res)))
            else
                log(string.format("[Method] %s(requires arguments)", fullName))
            end
        elseif vType == "table" then
            log(string.format("[Table ] %s", fullName))
            if not seen[v] then
                inspect(v, fullName)
            end
        else
            log(string.format("[Field ] %s = %s (%s)", fullName, formatResult(v), vType))
        end
    end
end

log("--- Standard Peripheral Methods ---")
local methods = peripheral.getMethods(side)
if methods then
    for _, name in ipairs(methods) do
        local fn = p[name]
        if type(fn) == "function" then
            local ok, res = pcall(fn)
            if ok then
                log(string.format("  %s() -> %s", name, formatResult(res)))
            else
                log(string.format("  %s() (requires arguments)", name))
            end
        end
    end
end

log("\n--- Full Object Scan ---")
inspect(p)

--file.close()
log("\nDone! Results saved to " .. filename)
file.close()