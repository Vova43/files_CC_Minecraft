local radarMon = peripheral.wrap("back")
if not radarMon then
    error("ERROR")
end

term.clear()
term.setCursorPos(1, 1)
print("TEST")
local tracks = radarMon.getTracks()

print(textutils.serialize(tracks))
