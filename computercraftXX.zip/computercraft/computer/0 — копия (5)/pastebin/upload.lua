--pastebin configuration
-- local API_DEV_KEY = "v1mO2INEooS603Tl4hruLtmhUSaCEHlk"
-- local USER_NAME   = "ZintarLinger"
-- local USER_PASS   = "dRqm3L_Rd@Lr2Ce"

-- local args = { ... }
-- local filename = args[1]

-- if not filename then
    -- print("Usage: upload [filename]")
    -- return
-- end

-- if not fs.exists(filename) then
    -- print("Error: File not found.")
    -- return
-- end

--Read target file
-- local file = fs.open(filename, "r")
-- local content = file.readAll()
-- file.close()

--1. Authorization: Getting User Session Key
-- print("Logging into Pastebin...")
-- local loginPayload = "api_dev_key=" .. textutils.urlEncode(API_DEV_KEY) ..
                     -- "&api_user_name=" .. textutils.urlEncode(USER_NAME) ..
                     -- "&api_user_password=" .. textutils.urlEncode(USER_PASS)

-- local loginRes = http.post("https://pastebin.com/api/api_post.php", loginPayload)

-- if not loginRes then
    -- print("Login connection failed!")
    -- return
-- end

-- local api_user_key = loginRes.readAll()
-- loginRes.close()

-- if api_user_key:match("Bad API request") or api_user_key:match("invalid") then
    -- print("Login Error: " .. api_user_key)
    -- return
-- end

--2. Uploading the actual file
-- print("Uploading file to your account...")
-- local uploadPayload = "api_option=paste" ..
                      -- "&api_dev_key=" .. textutils.urlEncode(API_DEV_KEY) ..
                      -- "&api_user_key=" .. textutils.urlEncode(api_user_key) ..
                      -- "&api_paste_code=" .. textutils.urlEncode(content) ..
                      -- "&api_paste_name=" .. textutils.urlEncode(filename) ..
                      -- "&api_paste_private=1" -- 1 = unlisted, 2 = private

-- local response = http.post("https://pastebin.com/api/api_post.php", uploadPayload)

-- if response then
    -- local resultUrl = response.readAll()
    -- response.close()
    
    -- if resultUrl:match("https://pastebin.com/api/api_post.php") then
        -- print("\nSuccess! Link:")
        -- print(resultUrl)
    -- else
        -- print("Upload failed: " .. resultUrl)
    -- end
-- else
    -- print("Server communication error!")
-- end

-- Pastebin Configuration using the official mod key
local API_DEV_KEY = "v1mO2INEooS603Tl4hruLtmhUSaCEHlk"

local args = { ... }
local filename = args[1]

if not filename then
    print("Usage: upload [filename]")
    return
end

if not fs.exists(filename) then
    print("Error: File not found.")
    return
end

-- Read target file
local file = fs.open(filename, "r")
local content = file.readAll()
file.close()

print("Connecting to pastebin.com... ")

-- Correct payload format from the official CC source code
local uploadPayload = "api_option=paste&" ..
                      "api_dev_key=" .. API_DEV_KEY .. "&" ..
                      "api_paste_format=lua&" ..
                      "api_paste_name=" .. textutils.urlEncode(filename) .. "&" ..
                      "api_paste_code=" .. textutils.urlEncode(content)

local response, err = http.post("https://pastebin.com/api/api_post.php", uploadPayload)

if response then
    local resultUrl = response.readAll()
    response.close()
    
    if resultUrl:match("https://pastebin.com") then
        print("Success!")
        print("Link: " .. resultUrl)
    else
        print("Upload failed: " .. resultUrl)
    end
else
    print("Failed.")
    if err then print("Reason: " .. tostring(err)) end
end
