local w, h = term.getSize()
-- Store current paths and file lists for both panels
local leftDir, rightDir = "", "" -- "", ""
local leftFiles = fs.list(leftDir)
local rightFiles = fs.list(rightDir)

local activePanel = "left"
local leftSel, rightSel = 1, 1
local leftOffset, rightOffset = 0, 0
local leftScrollX, rightScrollX = 0, 0
local showHelp = false
-- Group selection tables
local leftSelected, rightSelected = {}, {}

local function clearSelection(panel)
    if panel == "left" then leftSelected = {} else rightSelected = {} end
end

local function getSelectedCount(selectedTable)
    local count = 0
    for _ in pairs(selectedTable) do count = count + 1 end
    return count
end

-- Sorting function: folders at the top, then alphabetical order.
local function sortFiles(fileList, currentDir)
    table.sort(fileList, function(a, b)
        local pathA = fs.combine(currentDir, a)
        local pathB = fs.combine(currentDir, b)
        local isDirA = fs.isDir(pathA)
        local isDirB = fs.isDir(pathB)
        if isDirA ~= isDirB then
            return isDirA
        end
        return string.lower(a) < string.lower(b)
    end)
end

local function refreshPanel(panel)
    if panel == "left" then
        leftFiles = fs.list(leftDir)
        sortFiles(leftFiles, leftDir)
        if leftSel > #leftFiles then leftSel = math.max(1, #leftFiles) end
    else
        rightFiles = fs.list(rightDir)
        sortFiles(rightFiles, rightDir)
        if rightSel > #rightFiles then rightSel = math.max(1, #rightFiles) end
    end
end

-- Clear event buffer before processing custom input loop
local function clearEvent()
    os.queueEvent("dummy")
    while true do
        local e = os.pullEvent()
        if e == "dummy" then break end
    end
end

-- Popup prompt window for text input (File/Folder name)
local function promptInput(title)
	local winW, winH = 30, 5
    local sx = math.floor((w - winW) / 2)
    local sy = math.floor((h - winH) / 2)
    
    -- Draw the background window frame
    term.setBackgroundColor(colors.gray)
    for y = sy, sy + winH - 1 do
        term.setCursorPos(sx, y)
        term.write(string.rep(" ", winW))
    end
    
    term.setTextColor(colors.yellow)
    term.setCursorPos(sx + 2, sy + 1)
    term.write(title)
    
    -- Draw the input area background
    local fieldX = sx + 2
    local fieldY = sy + 3
    local fieldW = winW - 4 -- Visible width of the input box (26 characters)
    
    term.setBackgroundColor(colors.black)
    term.setTextColor(colors.white)
    term.setCursorPos(fieldX, fieldY)
    term.write(string.rep(" ", fieldW))
    
	clearEvent()
    
    -- Initialize input string variables
    local inputStr = ""
    
    -- Internal function to redraw only the text field with scrolling logic
    local function renderField()
        term.setBackgroundColor(colors.black)
        term.setTextColor(colors.white)
        term.setCursorPos(fieldX, fieldY)
        term.write(string.rep(" ", fieldW)) -- Clear box text
        
        -- Calculate scrolling window view offset
        local displayStr = inputStr
        if #inputStr > fieldW then
            displayStr = inputStr:sub(#inputStr - fieldW + 1)
        end
        
        term.setCursorPos(fieldX, fieldY)
        term.write(displayStr)
        
        -- Move the active blinking cursor to the end of the text line
        local cursorOffset = math.min(#inputStr, fieldW)
        term.setCursorPos(fieldX + cursorOffset, fieldY)
        term.setCursorBlink(true)
    end
    
    -- Custom input listener loop
    while true do
        renderField()
        local event, p1 = os.pullEvent()
        
        if event == "char" then
            -- Append normal text characters typed by user
            inputStr = inputStr .. p1
        elseif event == "key" then
            if p1 == keys.backspace then
                -- Remove last character
                if #inputStr > 0 then
                    inputStr = inputStr:sub(1, #inputStr - 1)
                end
            elseif p1 == keys.enter then
                -- Confirm input value
                term.setCursorBlink(false)
                --return (inputStr ~= "") and inputStr or path
				return (inputStr ~= "") and inputStr or nil
            elseif p1 == keys.layerUnknown or p1 == keys.esc then 
                -- Cancel action on ESC key press
                term.setCursorBlink(false)
                return nil
            end
        end
    end
end

-- #1
-- if event == "char" then
	-- if p1 then
		-- local charStr = tostring(p1)
		-- local leftPart = inputStr:sub(1, cursorPos)
		-- local rightPart = inputStr:sub(cursorPos + 1)
		-- inputStr = leftPart .. charStr .. rightPart
		-- cursorPos = cursorPos + #charStr
	-- end
-- Popup prompt window with cursor navigation, editing and scrolling
local function promptInputPath(title, path)
    local winW, winH = 30, 5
    local sx = math.floor((w - winW) / 2)
    local sy = math.floor((h - winH) / 2)
    
    -- Draw the background window frame
    term.setBackgroundColor(colors.gray)
    for y = sy, sy + winH - 1 do
        term.setCursorPos(sx, y)
        term.write(string.rep(" ", winW))
    end
    
    term.setTextColor(colors.yellow)
    term.setCursorPos(sx + 2, sy + 1)
    term.write(title)
    
    -- Text field bounds
    local fieldX = sx + 2
    local fieldY = sy + 3
    local fieldW = winW - 4 -- 26 characters visible
    
    -- Clear event buffer from the triggering key press
    clearEvent()
    
    -- Input state variables
    local inputStr = path or ""
    local cursorPos = #inputStr -- Cursor is at the end of the text initially
    local scrollOffset = 0      -- Scrolling viewport position
    
    -- Internal function to redraw text field and calculate accurate scrolling
    local function renderField()
        term.setBackgroundColor(colors.black)
        term.setTextColor(colors.white)
        term.setCursorPos(fieldX, fieldY)
        term.write(string.rep(" ", fieldW)) -- Clear input background
        -- Adjust scroll offset so the cursor is always visible on screen
        if cursorPos < scrollOffset then
            scrollOffset = cursorPos
        elseif cursorPos > scrollOffset + fieldW then
            scrollOffset = cursorPos - fieldW
        end
        -- Clamp scrolling if text gets shortened
        if #inputStr - scrollOffset < fieldW then
            scrollOffset = math.max(0, #inputStr - fieldW)
        end
        -- Get the visible slice of text and draw it
        local displayStr = inputStr:sub(scrollOffset + 1, scrollOffset + fieldW)
        term.setCursorPos(fieldX, fieldY)
        term.write(displayStr)
        -- Place the blinking hardware cursor at the relative position
        local relativeCursorX = cursorPos - scrollOffset
        term.setCursorPos(fieldX + relativeCursorX, fieldY)
        term.setCursorBlink(true)
    end
    
    -- Input listener loop
    while true do
        renderField()
        local event, p1 = os.pullEvent()
        -- if p1 then -> attempt to concatenate a nil value #1
        if event == "char" then
            -- INSERT character at current cursor position
            local leftPart = inputStr:sub(1, cursorPos)
            local rightPart = inputStr:sub(cursorPos + 1)
            inputStr = leftPart .. p1 .. rightPart
            cursorPos = cursorPos + 1 -- Move cursor right
            --inputStr = inputStr .. p1
        elseif event == "key" then
            if p1 == keys.backspace then
                -- DELETE character BEFORE cursor
                if cursorPos > 0 then
                    local leftPart = inputStr:sub(1, cursorPos - 1)
                    local rightPart = inputStr:sub(cursorPos + 1)
                    inputStr = leftPart .. rightPart
                    cursorPos = cursorPos - 1
                end
            elseif p1 == keys.delete then
                -- DELETE character AFTER cursor
                if cursorPos < #inputStr then
                    local leftPart = inputStr:sub(1, cursorPos)
                    local rightPart = inputStr:sub(cursorPos + 2)
                    inputStr = leftPart .. rightPart
                end
            elseif p1 == keys.left then
                -- Move cursor LEFT
                if cursorPos > 0 then
                    cursorPos = cursorPos - 1
                end
            elseif p1 == keys.right then
                -- Move cursor RIGHT
                if cursorPos < #inputStr then
                    cursorPos = cursorPos + 1
                end
            elseif p1 == keys.home then
                -- Jump to BEGINNING
                cursorPos = 0
            elseif p1 == keys.idAndTag or p1 == keys["end"] then
                -- Jump to END
                cursorPos = #inputStr
            elseif p1 == keys.enter then
                -- Confirm and return
                term.setCursorBlink(false)
                return (inputStr ~= "") and inputStr or path
            elseif p1 == keys.layerUnknown or p1 == keys.esc then 
                -- Cancel input on ESC
                term.setCursorBlink(false)
                return nil
            end
        end
    end
end

-- Operation progress window overlay
local function showProgressWindow(operation, currentFile, fromPath, toPath)
    local winW, winH = 36, 7
    local sx = math.floor((w - winW) / 2)
    local sy = math.floor((h - winH) / 2)
    
    term.setBackgroundColor(colors.gray)
    for y = sy, sy + winH - 1 do
        term.setCursorPos(sx, y)
        term.write(string.rep(" ", winW))
    end
    
    term.setTextColor(colors.yellow)
    term.setCursorPos(sx + 2, sy + 1)
    term.write("OPERATION: " .. operation:upper())
    
    term.setTextColor(colors.white)
    term.setCursorPos(sx + 2, sy + 3)
    term.write("Item: " .. currentFile:sub(1, winW - 10))
    
    if fromPath then
        term.setCursorPos(sx + 2, sy + 4)
        term.write("From: /" .. fromPath:sub(1, winW - 10))
    end
    if toPath then
        term.setCursorPos(sx + 2, sy + 5)
        term.write("To:   /" .. toPath:sub(1, winW - 10))
    end
    
    sleep(0.2) -- Short delay to visualize operation progress
	term.setBackgroundColor(colors.black)
end

-- Helper to draw file list inside a single panel
local function drawPanelList(files, currentDir, startX, mid, isActive, currentSel, selectedTable, offset, scrollX) 
    scrollX = scrollX or 0
    local maxDisplayedItems = h - 1 -- h - 4
    local maxVisibleWidth = mid - 3

    for i = 1, maxDisplayedItems do 
        local fileIndex = i + offset 
        local file = files[fileIndex] 
        term.setCursorPos(startX, i + 1) 

        if file then 
            local fullPath = fs.combine(currentDir, file) 
            if isActive and fileIndex == currentSel then 
                term.setBackgroundColor(colors.blue) 
            elseif selectedTable[file] then 
                term.setBackgroundColor(colors.green) 
            else 
                term.setBackgroundColor(colors.black) 
            end 

            if fs.isDir(fullPath) then 
                term.setTextColor(colors.yellow) 
            else 
                term.setTextColor(colors.white) 
            end 

            local displayName = file:sub(1 + scrollX, maxVisibleWidth + scrollX)

            local padding = maxVisibleWidth - #displayName
            if padding < 0 then padding = 0 end

            term.write(displayName .. string.rep(" ", padding)) 
        else 
            term.setBackgroundColor(colors.black) 
            term.write(string.rep(" ", maxVisibleWidth)) 
        end 
    end 
    term.setTextColor(colors.white) 
end

-- Help window overlay
local function drawHelpWindow()
    local hw, hh = 36, 11
    local sx = math.floor((w - hw) / 2)
    local sy = math.floor((h - hh) / 2)
    
    term.setBackgroundColor(colors.gray)
    for y = sy, sy + hh do term.setCursorPos(sx, y) term.write(string.rep(" ", hw)) end
    
    term.setTextColor(colors.yellow)
    term.setCursorPos(sx + 15, sy + 0) term.write("HELP")
    
    term.setTextColor(colors.white)
	local step = 1
    term.setCursorPos(sx + 2, sy + step)  term.write("Tab       - Switch panel") step = step + 1
    term.setCursorPos(sx + 2, sy + step)  term.write("Space     - Select multiple") step = step + 1
    term.setCursorPos(sx + 2, sy + step)  term.write("Enter     - Open folder/file") step = step + 1
	term.setCursorPos(sx + 2, sy + step)  term.write("Backspace - Back") step = step + 1
	term.setCursorPos(sx + 2, sy + step)  term.write("F         - Refresh active panel") step = step + 1
	term.setCursorPos(sx + 2, sy + step)  term.write("R         - Rename") step = step + 1
    term.setCursorPos(sx + 2, sy + step)  term.write("C / M     - Copy / Move selected") step = step + 1
    --term.setCursorPos(sx + 2, sy + step)  term.write("Delete    - Delete selected") step = step + 1
	term.setCursorPos(sx + 2, sy + step)  term.write("I         - Delete selected") step = step + 1
    --term.setCursorPos(sx + 2, sy + step)  term.write("F1 / F2   - Create File / Folder") step = step + 1
	term.setCursorPos(sx + 2, sy + step)  term.write("T / Y     - Create File / Folder") step = step + 1
    term.setCursorPos(sx + 2, sy + step)  term.write("H / Q     - Toggle Help / Exit") step = step + 1
	term.setTextColor(colors.yellow)
	term.setCursorPos(sx + 6, sy + step)  term.write("Commander by vova43 v1.1")
	term.setBackgroundColor(colors.black)
end

-- Function to get the last folder name and truncate it if it exceeds maxLength
local function getFinalFolderName(path, maxLength)
    -- If the path is empty, return root symbol or empty string
    if not path or path == "" then
        return ""
    end
    -- Extract the substring after the last slash '/'
    local finalName = path:match("([^/]+)$") or path
    -- Check if the length exceeds the limit
    if #finalName > maxLength then
        -- Calculate how many characters from the end we can keep
        -- Subtracting 2 to make room for the ".." dots
        local keepLength = maxLength - 2
        -- Prevent negative lengths or errors on very small limits
        if keepLength > 0 then
            finalName = ".." .. finalName:sub(#finalName - keepLength + 1)
        else
            finalName = finalName:sub(1, maxLength)
        end
    end
    return finalName
end

-- Main interface rendering loop
local function draw()
    term.clear()
	term.setBackgroundColor(colors.black)
    local mid = math.floor(w / 2)
    
    -- Directory path headers
    term.setBackgroundColor(colors.gray)
    term.setCursorPos(1, 1) term.clearLine()
	term.setCursorPos(2, 1) term.write(getFinalFolderName(leftDir, mid - 4))
    term.setCursorPos(mid + 2, 1) term.write(getFinalFolderName(rightDir, mid - 4))
    term.setBackgroundColor(colors.black)
    
    -- Panel vertical separator line
	for y = 2, h - 0 do term.setCursorPos(mid, y) term.write("|") end
    
	-- drawPanelList(leftFiles, leftDir, 2, mid, (activePanel == "left"), leftSel, leftSelected, leftOffset)
    -- drawPanelList(rightFiles, rightDir, mid + 2, mid, (activePanel == "right"), rightSel, rightSelected, rightOffset)
	drawPanelList(leftFiles, leftDir, 2, mid, (activePanel == "left"), leftSel, leftSelected, leftOffset, leftScrollX)
    drawPanelList(rightFiles, rightDir, mid + 2, mid, (activePanel == "right"), rightSel, rightSelected, rightOffset, rightScrollX)
    
    -- Command bar overlay placeholder
    -- term.setBackgroundColor(colors.gray)
    -- term.setCursorPos(1, h - 1) term.clearLine()
    -- term.write(" F1:NewFile | F2:NewDir | Del:Delete | H:Help")
	
    if showHelp then drawHelpWindow() end
end

-- Main
term.clear()
term.setBackgroundColor(colors.black)
term.setCursorPos(1, 1)

refreshPanel("left")
refreshPanel("right")

-- Core listener loop
while true do
    draw()
    local event, key = os.pullEvent("key")
    
    if showHelp then
        if key == keys.h then showHelp = false elseif key == keys.q then break end
    else
        if key == keys.q then
            break
        elseif key == keys.h then
            showHelp = true
        elseif key == keys.tab then
            activePanel = (activePanel == "left") and "right" or "left"
		end
		local success, err = pcall(function()
			if key == keys.up or key == keys.w then
				local maxDisplayedItems = h - 4
				if activePanel == "left" and leftSel > 1 then 
					leftSel = leftSel - 1
					if leftSel <= leftOffset then leftOffset = leftSel - 1 end
				elseif activePanel == "right" and rightSel > 1 then 
					rightSel = rightSel - 1 
					if rightSel <= rightOffset then rightOffset = rightSel - 1 end
				end
			elseif key == keys.down or key == keys.s then
				local maxDisplayedItems = h - 4
				if activePanel == "left" and leftSel < #leftFiles then 
					leftSel = leftSel + 1
					if leftSel > leftOffset + maxDisplayedItems then leftOffset = leftSel - maxDisplayedItems end
				elseif activePanel == "right" and rightSel < #rightFiles then 
					rightSel = rightSel + 1 
					if rightSel > rightOffset + maxDisplayedItems then rightOffset = rightSel - maxDisplayedItems end
				end
				
			elseif key == keys.right then
				if activePanel == "left" then
					leftScrollX = leftScrollX + 1
				elseif activePanel == "right" then
					rightScrollX = rightScrollX + 1
				end
			elseif key == keys.left then
				if activePanel == "left" then
					leftScrollX = math.max(0, leftScrollX - 1)
				elseif activePanel == "right" then
					rightScrollX = math.max(0, rightScrollX - 1)
				end
				
			elseif key == keys.space then
				local activeFiles = (activePanel == "left") and leftFiles or rightFiles
				local activeSel = (activePanel == "left") and leftSel or rightSel
				local selTable = (activePanel == "left") and leftSelected or rightSelected
				if #activeFiles > 0 then
					local file = activeFiles[activeSel]
					if selTable[file] then selTable[file] = nil else selTable[file] = true end
				end
				-- Next step
				-- local maxDisplayedItems = h - 4
				-- if activePanel == "left" and leftSel < #leftFiles then 
					-- leftSel = leftSel + 1
					-- if leftSel > leftOffset + maxDisplayedItems then leftOffset = leftSel - maxDisplayedItems end
				-- elseif activePanel == "right" and rightSel < #rightFiles then 
					-- rightSel = rightSel + 1 
					-- if rightSel > rightOffset + maxDisplayedItems then rightOffset = rightSel - maxDisplayedItems end
				-- end
			-- Next step
			elseif key == keys.b then
				local activeFiles = (activePanel == "left") and leftFiles or rightFiles
				local activeSel = (activePanel == "left") and leftSel or rightSel
				local selTable = (activePanel == "left") and leftSelected or rightSelected
				if #activeFiles > 0 then
					local file = activeFiles[activeSel]
					if selTable[file] then selTable[file] = nil else selTable[file] = true end
				end
				
				local maxDisplayedItems = h - 4
				if activePanel == "left" and leftSel < #leftFiles then 
					leftSel = leftSel + 1
					if leftSel > leftOffset + maxDisplayedItems then leftOffset = leftSel - maxDisplayedItems end
				elseif activePanel == "right" and rightSel < #rightFiles then 
					rightSel = rightSel + 1 
					if rightSel > rightOffset + maxDisplayedItems then rightOffset = rightSel - maxDisplayedItems end
				end
			elseif key == keys.enter then
				local currentDir = (activePanel == "left") and leftDir or rightDir
				local currentFiles = (activePanel == "left") and leftFiles or rightFiles
				local currentSel = (activePanel == "left") and leftSel or rightSel
				
				if #currentFiles > 0 then
					local selected = currentFiles[currentSel]
					local fullPath = fs.combine(currentDir, selected)
					
					if fs.isDir(fullPath) then
						if activePanel == "left" then leftDir = fullPath leftSel = 1 leftOffset = 0 clearSelection("left") refreshPanel("left")
						else rightDir = fullPath rightSel = 1 rightOffset = 0 clearSelection("right") refreshPanel("right") end
					else
						term.clear() term.setCursorPos(1, 1)
						shell.run("edit", fullPath)
						refreshPanel("left") refreshPanel("right")
					end
				end
				leftScrollX = 0
				rightScrollX = 0
			elseif key == keys.backspace then
				if activePanel == "left" and leftDir ~= "" then
					leftDir = fs.getDir(leftDir) leftSel = 1 leftOffset = 0 clearSelection("left") refreshPanel("left")
				elseif activePanel == "right" and rightDir ~= "" then
					rightDir = fs.getDir(rightDir) rightSel = 1 rightOffset = 0 clearSelection("right") refreshPanel("right")
				end
			elseif key == keys.z then
				local maxDisplayedItems = h - 4
				if activePanel == "left" and leftSel > 10 then 
					leftSel = leftSel - 10
					if leftSel <= leftOffset then leftOffset = leftSel - 10 end
					if leftOffset < 0 then leftOffset = 0 end
				elseif activePanel == "right" and rightSel > 10 then 
					rightSel = rightSel - 10
					if rightSel <= rightOffset then rightOffset = rightSel - 10 end
					if rightOffset < 0 then rightOffset = 0 end
				end
			elseif key == keys.x then
				local maxDisplayedItems = h - 4
				if activePanel == "left" and leftSel < #leftFiles then 
					leftSel = leftSel + 10
					if leftSel > leftOffset + maxDisplayedItems then leftOffset = leftSel - maxDisplayedItems end
				elseif activePanel == "right" and rightSel < #rightFiles then 
					rightSel = rightSel + 10 
					if rightSel > rightOffset + maxDisplayedItems then rightOffset = rightSel - maxDisplayedItems end
				end
			elseif key == keys.r then
				local currentDir = (activePanel == "left") and leftDir or rightDir
				local currentFiles = (activePanel == "left") and leftFiles or rightFiles
				local currentSel = (activePanel == "left") and leftSel or rightSel
				
				if #currentFiles > 0 then
					local selected = currentFiles[currentSel]
					local source = fs.combine(currentDir, selected)
					
					local newName = promptInputPath("Enter new name:", selected)
					if newName and newName ~= selected and newName ~= "" then
						local dest = fs.combine(currentDir, newName)
						if not fs.exists(dest) then
							showProgressWindow("rename", selected, source, dest)
							fs.move(source, dest)
							refreshPanel(activePanel)
						end
					end
					refreshPanel(activePanel)
				end
			--elseif key == keys.f1 then
			elseif key == keys.t then
				local name = promptInput("Enter new file name:")
				if name then
					local currentDir = (activePanel == "left") and leftDir or rightDir
					local fullPath = fs.combine(currentDir, name)
					term.clear() term.setCursorPos(1, 1)
					shell.run("edit", fullPath)
					refreshPanel(activePanel)
				end
			--elseif key == keys.f2 then
			elseif key == keys.y then
				local name = promptInput("Enter new folder name:")
				if name then
					local currentDir = (activePanel == "left") and leftDir or rightDir
					fs.makeDir(fs.combine(currentDir, name))
					refreshPanel(activePanel)
				end
			--elseif key == keys.delete then
			elseif key == keys.i then
				local srcDir = (activePanel == "left") and leftDir or rightDir
				local srcFiles = (activePanel == "left") and leftFiles or rightFiles
				local srcSel = (activePanel == "left") and leftSel or rightSel
				local selTable = (activePanel == "left") and leftSelected or rightSelected
				
				local targets = {}
				if getSelectedCount(selTable) > 0 then
					--
					for file in pairs(selTable) do table.insert(targets, file) end
				elseif #srcFiles > 0 then
					table.insert(targets, srcFiles[srcSel])
				end
				
				for _, file in ipairs(targets) do
					local fullPath = fs.combine(srcDir, file)
					showProgressWindow("delete", file, fullPath, nil)
					fs.delete(fullPath)
				end
				clearSelection(activePanel)
				refreshPanel("left") refreshPanel("right")
			elseif key == keys.f then
				refreshPanel(activePanel)
			elseif key == keys.c or key == keys.m then
				local isMove = (key == keys.m)
				local opName = isMove and "move" or "copy"
				
				local srcDir = (activePanel == "left") and leftDir or rightDir
				local dstDirS = (activePanel == "left") and rightDir or leftDir
				
				local srcFiles = (activePanel == "left") and leftFiles or rightFiles
				local srcSel = (activePanel == "left") and leftSel or rightSel
				local selTable = (activePanel == "left") and leftSelected or rightSelected
				
				local dstDir = promptInputPath("Enter new path:", dstDirS)
				if dstDir then
					local targets = {}
					if getSelectedCount(selTable) > 0 then
						for file in pairs(selTable) do table.insert(targets, file) end
					elseif #srcFiles > 0 then
						table.insert(targets, srcFiles[srcSel])
					end
					for _, file in ipairs(targets) do
						local source = fs.combine(srcDir, file)
						local dest = fs.combine(dstDir, file)
						if not fs.exists(dest) then
							showProgressWindow(opName, file, source, dest)
							if isMove then fs.move(source, dest) else fs.copy(source, dest) end
						end
					end
				end
				clearSelection(activePanel)
				refreshPanel("left") refreshPanel("right")
			end
		end)
		
		if not success then
			term.clear()
			term.setCursorPos(1,1)
			print("" .. tostring(err))
			local errorm = tostring(err):match("([^:]+)$") or tostring(err)
            errorm = errorm:match("^%s*(.-)%s*$")
			print("Error: " .. errorm)
			print("Press Enter to continue...")
			read()
			draw()
		end
	end
end
clearEvent()
term.clear()
term.setCursorPos(1,1)