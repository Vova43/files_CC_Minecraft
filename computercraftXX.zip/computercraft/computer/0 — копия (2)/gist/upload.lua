--[[
-- Конфигурация
local GITHUB_TOKEN = "ЗДЕСЬ_ВАШ_ТОКЕН"

local args = { ... }
local filename = args

if not filename then
    print("Использование: upload [имя_файла]")
    return
end

if not fs.exists(filename) then
    print("Ошибка: Файл '" .. filename .. "' не найден.")
    return
end

-- Читаем файл из игры
local file = fs.open(filename, "r")
local content = file.readAll()
file.close()

print("Отправка файла на ваш GitHub Gist...")

-- Подготавливаем JSON вручную (простой способ без внешних библиотек)
-- Экранируем переносы строк и кавычки для JSON format
local safeContent = content:gsub("\\", "\\\\"):gsub('"', '\\"'):gsub("\n", "\\n"):gsub("\r", "")

local jsonPayload = '{"description": "Загружено из Minecraft CC:Tweaked", "public": false, "files": {"' .. filename .. '": {"content": "' .. safeContent .. '"}}}'

-- Отправляем POST-запрос на GitHub API
local response, err = http.post(
    "https://github.com",
    jsonPayload,
    {
        ["Authorization"] = "Bearer " .. GITHUB_TOKEN,
        ["Content-Type"] = "application/json",
        ["User-Agent"] = "CC-Tweaked-Client"
    }
)

if response then
    local responseText = response.readAll()
    response.close()
    
    -- Находим ссылку на созданный Gist
    local html_url = responseText:match('"html_url"%s*:%s*"(https://gist%.github%.com/[%w%d/_]+)"')
    
    if html_url then
        print("\nУспешно загружено на ваш аккаунт!")
        print("Ссылка на код:")
        print(html_url)
    else
        print("Ошибка: Файл создан, но не удалось прочитать ссылку.")
    end
else
    print("Ошибка запроса!")
    if err then print("Причина: " .. err) end
end
--
-- Конфигурация
local GITHUB_TOKEN = "ЗДЕСЬ_ВАШ_ТОКЕН"

local args = { ... }
local filename = args[1] -- Исправлено: получение имени файла из аргументов

if not filename then
    print("Использование: upload [имя_файла]")
    return
end

if not fs.exists(filename) then
    print("Ошибка: Файл '" .. filename .. "' не найден.")
    return
end

-- Читаем файл из игры
local file = fs.open(filename, "r")
local content = file.readAll()
file.close()

print("Отправка файла на ваш GitHub Gist...")

-- Подготавливаем JSON вручную (простой способ без внешних библиотек)
-- Экранируем переносы строк и кавычки для JSON формата
local safeContent = content:gsub("\\", "\\\\"):gsub('"', '\\"'):gsub("\n", "\\n"):gsub("\r", "")

local jsonPayload = '{"description": "Загружено из Minecraft CC:Tweaked", "public": false, "files": {"' .. filename .. '": {"content": "' .. safeContent .. '"}}}'

-- Отправляем POST-запрос на GitHub API
-- Важно: для работы с Gists адрес изменен с общего github.com на ://github.com
local response, err = http.post(
    "https://://github.com",
    jsonPayload,
    {
        ["Authorization"] = "Bearer " .. GITHUB_TOKEN,
        ["Content-Type"] = "application/json",
        ["User-Agent"] = "CC-Tweaked-Client"
    }
)

if response then
    local responseText = response.readAll()
    response.close()
    
    -- Находим ссылку на созданный Gist
    local html_url = responseText:match('"html_url"%s*:%s*"(https://gist%.github%.com/[%w%d/_%-]+)"')
    
    if html_url then
        print("\nУспешно загружено на ваш аккаунт!")
        print("Ссылка на код:")
        print(html_url)
    else
        print("Ошибка: Не удалось распознать ссылку в ответе GitHub.")
    end
else
    print("Ошибка запроса!")
    if err then print("Причина: " .. err) end
end
]]

-- Configuration
local GITHUB_TOKEN = "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"

local args = { ... }
local filename = args[1] -- Corrected: getting the filename from arguments

if not filename then
    print("Usage: upload [filename]")
    return
end

if not fs.exists(filename) then
    print("Error: File '" .. filename .. "' not found.")
    return
end

-- Read file from the game
local file = fs.open(filename, "r")
local content = file.readAll()
file.close()

print("Uploading file to your GitHub Gist...")

-- Manually prepare JSON (simple way without external libraries)
-- Escape newlines and quotes for JSON format
local safeContent = content:gsub("\\", "\\\\"):gsub('"', '\\"'):gsub("\n", "\\n"):gsub("\r", "")

local jsonPayload = '{"description": "Uploaded from Minecraft CC:Tweaked", "public": false, "files": {"' .. filename .. '": {"content": "' .. safeContent .. '"}}}'

-- Send POST request to GitHub API
-- Important: Changed to the correct endpoint for Gists ://github.com
local response, err = http.post(
    "https://://github.com",
    jsonPayload,
    {
        ["Authorization"] = "Bearer " .. GITHUB_TOKEN,
        ["Content-Type"] = "application/json",
        ["User-Agent"] = "CC-Tweaked-Client"
    }
)

if response then
    local responseText = response.readAll()
    response.close()
    
    -- Find the URL of the created Gist
    local html_url = responseText:match('"html_url"%s*:%s*"(https://gist%.github%.com/[%w%d/_%-]+)"')
    
    if html_url then
        print("\nSuccessfully uploaded to your account!")
        print("Code link:")
        print(html_url)
    else
        print("Error: Failed to recognize the link in the GitHub response.")
    end
else
    print("Request failed!")
    if err then print("Reason: " .. err) end
end
