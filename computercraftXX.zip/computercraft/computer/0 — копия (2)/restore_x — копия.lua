local args = { ... }
local code = args[1]

if not code then
    print("Usage: restore <pastebin_code>")
    return
end

if not http then
    printError("Error: HTTP API is disabled!")
    return
end

print("Downloading archive from Pastebin...")
local response = http.get("https://pastebin.com" .. code)

if not response then
    printError("Failed to download archive. Check your code.")
    return
end

local content = response.readAll()
response.close()

print("Unpacking data...")
local archive = textutils.unserialize(content)

if type(archive) ~= "table" then
    printError("Error: Invalid archive format.")
    return
end

-- Восстанавливаем файлы
for path, data in pairs(archive) do
    -- Если файл лежал в папке, создаем эту папку, если её нет
    local dir = fs.getDir(path)
    if dir ~= "" and not fs.exists(dir) then
        fs.makeDir(dir)
    end

    -- Записываем данные в файл
    local f = fs.open(path, "w")
    if f then
        f.write(data)
        f.close()
        print("Restored: " .. path)
    end
end

print("\n[DONE] All files restored successfully!")
