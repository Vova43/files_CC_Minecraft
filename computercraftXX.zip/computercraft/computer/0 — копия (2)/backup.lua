-- Утилита для автоматической выгрузки всех файлов на Pastebin
local function uploadFile(path)
    -- Пропускаем системные папки (rom) и саму утилиту
    if path == "rom" or path == "backup.lua" or path == "backup" then 
        return 
    end

    if fs.isDir(path) then
        -- Если это папка, сканируем её содержимое
        local files = fs.list(path)
        for _, file in ipairs(files) do
            uploadFile(fs.combine(path, file))
        end
    else
        -- Если это файл, загружаем его через встроенное API pastebin
        print("Uploading: " .. path)
        
        -- Читаем содержимое файла
        local f = fs.open(path, "r")
        local content = f.readAll()
        f.close()

        -- Формируем имя для Pastebin
        local pasteName = "CC_Backup_" .. path

        -- Отправляем запрос к API Pastebin через встроенную утилиту
        local p = shell.run("pastebin", "put", path)
        -- К сожалению, встроенный pastebin просто пишет код в консоль.
        -- Чтобы сделать это красиво и сохранить коды, используем прямой HTTP запрос:
    end
end

-- Улучшенная версия с сохранением ссылок в файл log.txt
local function smartBackup()
    if not http then
        printError("Error: HTTP API is disabled on this server!")
        return
    end

    local files = fs.list("")
    local log = fs.open("backup_log.txt", "w")
    log.writeLine("=== BACKUP CODES ===")

    for _, file in ipairs(files) do
        if file ~= "rom" and file ~= "backup.lua" and file ~= "backup_log.txt" then
            if not fs.isDir(file) then
                print("Uploading " .. file .. "...")
                
                -- Читаем файл
                local f = fs.open(file, "r")
                local text = f.readAll()
                f.close()

                -- Отправляем на Pastebin напрямую через HTTP POST
                local response = http.post(
                    "https://pastebin.com",
                    "api_option=paste&api_dev_key=0b20de043ec13dca60ec68dddf7f2e9e&api_paste_code=" .. 
                    text:urlEncode() .. "&api_paste_name=" .. file
                )

                if response then
                    local resText = response.readAll()
                    response.close()
                    if resText:find("https://pastebin.com") then
                        local code = resText:sub(21)
                        print("Success! Code: " .. code)
                        log.writeLine(file .. " -> " .. code)
                    else
                        print("Error uploading " .. file .. ": " .. resText)
                    end
                else
                    print("Failed to connect to Pastebin for " .. file)
                end
                sleep(0.5) -- Небольшая пауза, чтобы Pastebin не заблокировал за спам
            end
        end
    end
    log.close()
    print("\nDone! All codes saved to 'backup_log.txt'")
end

smartBackup()
