-- Функция для URL-кодирования (необходима для отправки данных)
local function urlEncode(str)
    if str then
        str = str:gsub("\n", "\r\n")
        str = str:gsub("([^%w %-%_%.%~])", function(c)
            return string.format("%%%02X", string.byte(c))
        end)
        str = str:gsub(" ", "+")
    end
    return str
end

local archive = {}

-- Функция рекурсивного обхода всех папок и файлов
local function scanDirectory(dir)
    local list = fs.list(dir)
    for _, item in ipairs(list) do
        local path = fs.combine(dir, item)
        
        -- Игнорируем систему и саму утилиту
        if path ~= "rom" and path ~= "backup.lua" and path ~= "restore.lua" then
            if fs.isDir(path) then
                scanDirectory(path) -- Если папка, заходим внутрь
            else
                -- Если файл, читаем его содержимое
                local f = fs.open(path, "r")
                if f then
                    archive[path] = f.readAll()
                    f.close()
                    print("Packed: " .. path)
                end
            end
        end
    end
end

local function runBackup()
    if not http then
        printError("Error: HTTP API is disabled!")
        return
    end

    print("Scanning and packing files...")
    scanDirectory("")

    -- Сериализуем (превращаем таблицу в текст)
    local serializedData = textutils.serialize(archive)
    
    print("Uploading archive to Pastebin...")
    local encodedData = urlEncode(serializedData)
    local encodedName = urlEncode("CC_Full_Backup")

    local response = http.post(
        "https://pastebin.com",
        "api_option=paste&api_dev_key=0b20de043ec13dca60ec68dddf7f2e9e" ..
        "&api_paste_code=" .. encodedData .. 
        "&api_paste_name=" .. encodedName
    )

    if response then
        local resText = response.readAll()
        response.close()
        if resText:find("https://pastebin.com") then
            local code = resText:sub(22) -- Получаем чистый код
            print("\n[SUCCESS] Archive uploaded!")
            print("Your restore code is: " .. code)
            
            -- Сохраняем код на всякий случай локально
            local log = fs.open("backup_code.txt", "w")
            log.write(code)
            log.close()
        else
            printError("Pastebin error: " .. resText)
        end
    else
        printError("Failed to connect to Pastebin.")
    end
end

runBackup()
