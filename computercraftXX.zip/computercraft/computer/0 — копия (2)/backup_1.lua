-- Функция для URL-кодирования строк (исправление ошибки)
local function urlEncode(str)
    if str then
        str = str:gsub("\n", "\r\n")
        str = str:gsub("([^%w %-%_%.%~])", function(c)
            return string.format("%%%02X", string.byte(c))
        end)
        str = str:gsub(" ", "+")
    end
    return str
end

local function smartBackup()
    if not http then
        printError("Error: HTTP API is disabled on this server!")
        return
    end

    local files = fs.list("")
    local log = fs.open("backup_log.txt", "w")
    log.writeLine("=== BACKUP CODES ===")

    for _, file in ipairs(files) do
        -- Игнорируем систему, сам скрипт и файл логов
        if file ~= "rom" and file ~= "backup.lua" and file ~= "backup" and file ~= "backup_log.txt" then
            if not fs.isDir(file) then
                print("Uploading " .. file .. "...")
                
                -- Читаем файл
                local f = fs.open(file, "r")
                local text = f.readAll()
                f.close()

                -- Безопасное кодирование текста и имени файла
                local encodedText = urlEncode(text)
                local encodedName = urlEncode(file)

                -- Отправляем на Pastebin напрямую через HTTP POST
                local response = http.post(
                    "https://pastebin.com",
                    "api_option=paste&api_dev_key=0b20de043ec13dca60ec68dddf7f2e9e" ..
                    "&api_paste_code=" .. encodedText .. 
                    "&api_paste_name=" .. encodedName
                )

                if response then
                    local resText = response.readAll()
                    response.close()
                    if resText:find("https://pastebin.com") then
                        local code = resText:sub(22) -- Извлекаем чистый код из ссылки
                        print("Success! Code: " .. code)
                        log.writeLine(file .. " -> " .. code)
                    else
                        print("Error uploading " .. file .. ": " .. resText)
                    end
                else
                    print("Failed to connect to Pastebin for " .. file)
                end
                sleep(0.5) -- Защита от блокировки за спам запросами
            end
        end
    end
    log.close()
    print("\nDone! All codes saved to 'backup_log.txt'")
end

smartBackup()
